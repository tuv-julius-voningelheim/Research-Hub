---
typ: insight
name: "Appendix ABC erzeugt systemische Reibung auf TÜV-Seite — nicht nur ein Kundenproblem"
confidence: Hoch
priority: Hoch
erstellt: "2026-07-08"
---

# Insight: Appendix ABC erzeugt systemische Reibung auf TÜV-Seite — nicht nur ein Kundenproblem

**Insight:** Die mangelhafte Datenstruktur des Appendix ABC — redundante Felder, fehleranfällige Kundeneingaben ("Best Guess" ohne Verständnis der Codes), kein zentraler versionierter Zugang, kein Änderungsprotokoll — produziert auf TÜV-Seite systematisch unnötige Arbeit: Rückfragen, manuelle Korrekturen, Blockaden zu Beginn der Bewertung. Das ist kein Randphänomen, sondern ein strukturell in das Tool eingebautes Problem, das rollenübergreifend jede am Prozess beteiligte Person betrifft. Ein bloßes "Digitalisieren" des bestehenden Appendix ABC löst diese Reibung nicht — es braucht eine Neudefinition der Datenstruktur mit Validierungslogik und Single-Source-of-Truth-Architektur.

**Stützende Themes:** [[Theme-Appendix-ABC-Datenqualitaet]], [[Theme-Tool-Fragmentierung]], [[Theme-Fehlende-Aenderungstransparenz]]

## Evidenz
**Stützende Zitate:**
> „das Nächste ist dann für mich wirklich das Wichtigste, dieser Appendix ABC quasi... es kommen immer noch zu Rückfragen, auf jeden Fall... da geht das bisschen hin und her und das kann viel Zeit kosten." — INT-001

> „gibt so ein paar Redundanzen... Die gleiche Information oder ähnlich habe ich aber dann noch mal in diesen Sheets dahinter... und die sind oft widersprüchlich" — INT-001

> „auf jeden Fall der Gedanke, auf jeden Fall der Richtige, genau, dass man den überführt von Excel in in 'ne Datenbankl ösung" — INT-001

> „Der normale Weg ist 'Hey, das ist mein Produkt' und dann sagen wir 'Füll mal bitte den Appendix ABC aus, die versuchen das nach dem Best Guest zu machen, ohne zu wissen, warum wir was anfragen.'" — INT-002

> „Derzeit ist der Appendix A. B. C. die vollendete Wahrheit, die maßgeblich sein muss... Und auch das Dokument, das am häufigsten verändert wird, logischerweise. Weil es am unrichtigsten ist." — INT-002

**Business Impact:** Jedes durch Appendix-ABC-Fehler ausgelöste Hin-und-Her verzögert Application Management und Assessment-Start. Das Problem betrifft ALLE befragten TÜV-Rollen rollenübergreifend: TD-Bewerter (Code-Fehler), Dual-Bewerter/Auditor (Blackbox für Kunden), Customer Specialist (größter Zeitfresser im Application Review). Zusätzlich: Kunden berichten direkt an CS, dass der ABC schwierig ist — also auch auf Kundenseite belegt.

**Design Implication:** Die neue Plattform darf nicht einfach die Excel-Struktur in eine Datenbank übertragen. Sie braucht: (1) kontextbezogene Kunden-Guidance beim Ausfüllen inkl. Wizard, (2) automatische Validierungslogik (bestimmte fehlerhafte Eingaben schlicht verhindern), (3) Single-Source-of-Truth für Supplier-Zuordnungen, (4) Versionierung mit sofortigem Zugang für alle Rollen, (5) Änderungsprotokoll mit optionaler Kundenbenachrichtigung, (6) klarer Prozessschritt-Kontext (wann ABC bei Change Notification updaten).

✅ **Confidence: Hoch** — Belegt aus 3 Interviews (INT-001 TD-Bewerter, INT-002 Dual-Bewerter/Auditor, INT-003 Customer Specialist), konsistent aus unterschiedlichen Rollenperspektiven, bestätigt durch direktes Kundenfeedback an INT-003.

## Referenz
Wenn die Evidenz dünn ist: KEIN Insight anlegen — stattdessen in [[SOP-Analyseprozess]] Research Gaps.
→ Evidenz hier als ausreichend für einen vorläufigen Insight bewertet, da Markus das Problem aus drei verschiedenen Perspektiven beschreibt (Kundenseite, Bewertungsseite, Strukturseite). Confidence explizit als Niedrig gekennzeichnet.
