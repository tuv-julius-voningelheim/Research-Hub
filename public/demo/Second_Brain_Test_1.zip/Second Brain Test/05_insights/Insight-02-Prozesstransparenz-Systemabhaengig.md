---
typ: insight
name: "Prozesstransparenz und Projektübersicht sind systemisch personenabhängig statt strukturell gesichert"
confidence: Hoch
priority: Hoch
erstellt: "2026-07-08"
---

# Insight: Prozesstransparenz und Projektübersicht sind systemisch personenabhängig statt strukturell gesichert

**Insight:** Ob ein Mitarbeitender seinen Projektstatus sieht, welche Working Instructions gelten, und ob er weiß, was als nächstes von ihm erwartet wird — all das hängt aktuell davon ab, ob eine bestimmte Person gerade verfügbar ist, das System diszipliniert gepflegt hat, oder ob jemand manuell nachgefragt hat. Das ist kein Versagen einzelner Mitarbeitender, sondern ein strukturelles Design-Problem: Die Systeme PSE 2.0, Appendix ABC und interne Kommunikationskanäle sind nicht so gebaut, dass sie Konsistenz und Verantwortungsklarheit erzwingen. Alle drei befragten Rollen beschreiben denselben Kern: Sie wissen nicht verlässlich, was gerade passiert, bis sie aktiv nachschauen oder fragen.

**Stützende Themes:** [[Theme-Prozesstransparenz-Projektuebersicht]], [[Theme-Schnittstellen-Bottlenecks-International]], [[Theme-Tool-Fragmentierung]]

## Evidenz
**Stützende Zitate:**
> „wenn die Datenqualität gut ist, wie es im PSE 20 eingetragen ist, dann sehe ich da eigentlich alles... wenn das so gehandhabt wird, dann habe ich eigentlich keinerlei Übersicht mehr." — INT-001

> „ich muss immer wieder die Working Instructions der aktuellen Version auch daneben legen... Es kostet schon immer wieder Zeit" — INT-001

> „Tracking von Projektstatus ist mit Sicherheit eine wichtige Sache. wenn man das hier einbauen könnte wie bei einem DHL Paket." — INT-002

> „da kriege ich im Endeffekt selber eine Liste, die ist nicht schön, aber im Endeffekt einfach nur, wo ich auch wirklich so Kleinigkeiten einfach reinschreibe... damit ich nicht in Tagen wieder denke, was ist denn da der letzte Stand." — INT-003

> „das wäre cool, dass man so das so sehen könnte, okay bei wem liegt gerade der Ball in dem Sinne und muss ich überhaupt irgendwas machen, muss ich aktiv werden." — INT-003

**Business Impact:** Systemische Personenabhängigkeit skaliert nicht: Je größer das Team, je mehr internationale Projekte, je häufiger Prozessänderungen, je mehr Rollen involviert — desto lauter wird das Problem. INT-003 zeigt: Sogar erfahrene Mitarbeitende (4 Jahre) behelfen sich mit improvisierten Excel-Listen und manueller Nachverfolgung. Das ist ein systemisches Versagen, nicht ein persönliches.

**Design Implication:** MACE Application sollte Prozesstransparenz und Verantwortungsklarheit als systemische Eigenschaften implementieren: (1) Echtzeit-Projektstatus mit klarer "Wer hat den Ball?"-Anzeige, (2) automatische Benachrichtigungen bei Handlungsbedarf, (3) kontextbezogene Working Instructions pro Projekttyp, (4) Produktdatenbank mit Zugriffsrechten für alle relevanten Rollen ohne Vermittlerperson.

✅ **Confidence: Hoch** — Belegt aus 3 Interviews mit konsistenten Beschreibungen des gleichen strukturellen Problems aus unterschiedlichen Rollenperspektiven (TD-Bewerter, Dual-Bewerter/Auditor, Customer Specialist+Auditor). Das "selbstgebaute Excel-Workaround"-Muster ist ein starkes strukturelles Signal.
