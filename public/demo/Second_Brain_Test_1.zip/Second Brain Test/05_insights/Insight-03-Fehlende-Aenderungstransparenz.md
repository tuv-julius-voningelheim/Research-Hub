---
typ: insight
name: "Fehlende Änderungstransparenz perpetuiert Datenfehler statt sie zu beheben"
confidence: Niedrig
priority: Mittel
erstellt: "2026-07-08"
---

# Insight: Fehlende Änderungstransparenz perpetuiert Datenfehler statt sie zu beheben

**Insight:** Wenn TÜV-Mitarbeitende Kundendaten korrigieren (z. B. falsche Codes), ohne dass der Kunde diese Korrektur sieht und versteht, entsteht kein Lerneffekt. Das System bleibt "dumm": Derselbe Fehler kann beim nächsten Projekt erneut gemacht werden. Gleichzeitig fehlt TÜV ein Änderungsprotokoll, das im Falle eines regulatorischen Audits oder Disputes belegt, wer was wann warum geändert hat. Die fehlende Transparenz ist also sowohl ein operationelles Problem (fehlender Lerneffekt) als auch ein regulatorisches Risiko.

**Stützende Themes:** [[Theme-Fehlende-Aenderungstransparenz]], [[Theme-Appendix-ABC-Datenqualitaet]]

## Evidenz
**Stützende Zitate:**
> „dementsprechend hat man 'ne Verdummung von einem System oder eher gesagt, keine Verbesserung von einem dummen System." — INT-002

> „Es ist unsere Verantwortung, unsere Akkreditierung, wir legen fest, wie die Codes sind, Rücksprache mit dem Kunden." — INT-002

> „Wann wird welche Änderung wie gemacht, wer hat sie gemacht, wie wird sie gehighlightet, der Kunde sieht nicht, wenn wir was anpassen" — INT-002

**Business Impact:** Ohne Änderungstransparenz bleibt der Beratungs-Overhead bei Code-Fehlern dauerhaft hoch. Kunden verbessern ihre Eingaben nicht, weil sie keine Rückmeldung über Korrekturen erhalten. Langfristig: Qualitätssteigerung der Kundendaten ist strukturell unmöglich.

**Design Implication:** Änderungsprotokoll ist kein "Nice-to-Have", sondern eine regulatorische und operative Notwendigkeit. Umsetzbar als: versionierter Datensatz mit Zeitstempel/User, optionale Kundenbenachrichtigung per Toggle, Specification-Request für formale Rückkopplung.

⚠️ **Confidence: Niedrig** — Nur INT-002. Obwohl die Aussage direkt und explizit ist, braucht es weitere Bestätigung aus anderen Rollen (Customer Specialist, der im Alltag Codes einträgt) und aus der Kundenperspektive.

## Referenz
Wenn die Evidenz dünn ist: KEIN Insight anlegen — stattdessen in [[SOP-Analyseprozess]] Research Gaps.
→ Trotz einer Quelle als Insight gewertet, weil es sich um ein explizit benanntes "Riesenproblem" handelt (direkte Evidenz) mit klarer kausaler Beschreibung des Mechanismus. Confidence bleibt Niedrig und Insight als vorläufig markiert.
