# Anweisungen: User-Research Second Brain

Dieses Vault ist ein automatisiertes Research-Repository. Deine Aufgabe: rohe Transkripte in
`00_inbox-raw` wie ein erfahrener User Researcher verarbeiten und strukturiert auf die
bestehenden Ordner verteilen — dabei bestehende Inhalte ANREICHERN statt DUPLIZIEREN.

## Grundprinzip (wichtigste Regel überhaupt)

Bevor du IRGENDEINE neue Notiz anlegst: durchsuche IMMER zuerst den Ziel-Ordner nach
bestehenden Notizen, die thematisch bereits passen. 
- Passt eine bestehende Notiz → dort ergänzen (siehe "Update-Regeln" pro Typ unten)
- Passt keine → neue Notiz anlegen, aber in der Notiz explizit begründen, warum keine
  bestehende Notiz gepasst hat

Ziel: Am Ende soll es z. B. GENAU EIN Theme "Vertrauen in Automatisierung" geben, das über
mehrere Interviews hinweg wächst — nicht drei ähnliche Theme-Notizen mit leicht anderem Namen.

## Ordnerstruktur (exakt diese Namen verwenden)

- `00_inbox-raw` — unverarbeitete Transkripte (Input)
- `01_interviews` — verarbeitete Interview-Notizen (Meaning Units + Codes)
- `02_themes`
- `03_pain points`
- `04_needs`
- `05_insights`
- `06_recommendations`
- `07_personas`
- `08_methods` — SOP, Definitionen, Templates (nur lesen, nicht verändern)
- `09_archive` — hierhin wandert das Rohtranskript nach Abschluss

## Ablauf pro neuem Transkript in 00_inbox-raw

### Schritt 0 — Vorbereitung
Lies `08_methods/SOP-Analyseprozess.md` und `08_methods/Definitionen.md` vollständig, bevor
du irgendetwas analysierst. Diese Dateien sind die verbindliche Methodik, keine Vorschläge.

Vergib eine stabile Interview-ID nach dem Schema `P##` (P01, P02, ...) — prüfe zuerst in
`01_interviews`, welche IDs bereits vergeben sind, und nimm die nächste freie Nummer.

### Schritt 1 — Interview-Notiz erstellen
Neue Notiz in `01_interviews`, benannt nach der Interview-ID (z. B. `P03.md`).
Nutze `08_methods/templates/Template-Interview.md` als Grundlage (Frontmatter-Platzhalter durch
echte Werte ersetzen, `{{title}}`/`{{date}}`-Syntax nicht stehen lassen).
Fülle Kontext-Abschnitt aus (Schritt 1 der SOP: lesen ohne zu coden).
Zerlege das Transkript in Meaning Units, vergib Codes (`#code/...`), bleib nah an der
Wortwahl der Person — keine vorschnelle Abstraktion.

### Schritt 2 — Mit bestehenden Themes abgleichen (Dedup-Kernschritt)
Für jeden Code: durchsuche `02_themes` nach einem inhaltlich passenden Theme.
- **Passt ein Theme:** öffne die Theme-Notiz, erhöhe `interview_count`, ergänze
  `Zugehörige Codes`, ergänze ein neues repräsentatives Zitat (falls das bestehende Set noch
  keins aus diesem Interview enthält), aktualisiere `confidence` gemäß Definitionen.md,
  ergänze `Widersprechende Evidenz` falls vorhanden. NICHTS aus der bestehenden Notiz löschen.
- **Kein Theme passt:** neue Theme-Notiz mit `Template-Theme.md` anlegen, UND im Abschnitt
  "Offene Fragen" oder als Kommentar kurz vermerken, warum kein bestehendes Theme gepasst hat.

### Schritt 3 — Pain Points
Gleiche Dedup-Logik wie bei Themes: erst `03_pain points` durchsuchen, ob eine bestehende
Notiz die gleiche konkrete Reibung beschreibt (auch wenn aus anderem Interview). Falls ja:
Evidence Count erhöhen, Interview-ID ergänzen, ggf. Severity neu bewerten (nie automatisch
abschwächen, nur weil mehr Personen es weniger schlimm fanden — Severity bleibt am
schlimmsten berichteten Fall orientiert). Falls nein: neue Notiz mit
`Template-Pain-Point.md`, verlinkt auf GENAU EIN Theme.

### Schritt 4 — Needs
Gleiche Logik. Zusätzlich: `Latent`-Needs immer explizit als Inferenz kennzeichnen, nie als
direkte Aussage der Person darstellen.

### Schritt 5 — Insights
NUR anlegen, wenn die Evidenz mehrere Themes/Pain Points verbindet UND ausreichend stark ist
(siehe Definitionen.md). Ist die Evidenz dünn: NICHT als Insight anlegen, sondern als
offene Frage im Abschnitt "Research Gaps" der betroffenen Theme-Notiz vermerken.
Bei Dedup: prüfe `05_insights`, ob ein bestehendes Insight durch die neue Evidenz gestärkt
wird — dann dort `confidence` und stützende Zitate ergänzen, statt ein Duplikat anzulegen.

### Schritt 6 — Recommendations
Nur anlegen, wenn ein neues Insight das rechtfertigt. Jede Recommendation braucht genau ein
Anker-Insight. Bei Dedup: prüfe `06_recommendations` auf bereits bestehende, passende
Empfehlungen — dort ergänzen statt duplizieren.

### Schritt 7 — Personas (strenge Sonderregel)
Personas dürfen NUR entstehen oder aktualisiert werden, wenn mindestens 3 unterschiedliche
Interviews ein konsistentes Muster zeigen (Rolle, Ziele, Themes, Pain Points stimmen überein).
- Weniger als 3 Interviews: KEINE Persona-Notiz anlegen. Stattdessen in der jeweiligen
  Interview-Notiz einen Vermerk `mögliches Segment: [Beschreibung]` machen, damit es beim
  dritten passenden Interview wieder auffindbar ist.
- Ab 3 Interviews mit gleichem Muster: EINE Persona-Notiz in `07_personas` anlegen bzw.,
  falls eine ähnliche Proto-Persona schon existiert, DIESE erweitern (Interview-Liste
  ergänzen, `status` von `proto-persona` ggf. auf `bestätigt` setzen) — niemals eine zweite,
  fast identische Persona-Notiz für dasselbe Segment anlegen.
- Bei Widersprüchen zwischen Interviews eines vermeintlich gleichen Segments: die Persona
  NICHT künstlich glattziehen — Widersprüche im Abschnitt Kontext offen vermerken.

### Schritt 8 — Qualitätscheck
Vor Abschluss `08_methods/Qualitäts-Checkliste.md` komplett durchgehen. Jeden nicht
erfüllten Punkt entweder beheben oder explizit als Lücke vermerken — nicht stillschweigend
übergehen.

### Schritt 9 — Archivieren
Erst wenn Schritt 1-8 abgeschlossen sind: das Rohtranskript aus `00_inbox-raw` nach
`09_archive` verschieben (nicht kopieren — es soll nicht doppelt existieren).

## Feste Regeln (gelten in jedem Schritt)

- Zitate IMMER wörtlich übernehmen — nie glätten, umformulieren oder grammatikalisch
  "verbessern"
- Nie Sentiment-Scores oder Häufigkeits-/Word-Cloud-Analysen als Ersatz für echte
  thematische Analyse nutzen
- Wichtigkeit/Priorität nie allein nach Häufigkeit vergeben — immer Impact × Evidenzqualität
  × Wiederholung × Severity zusammen betrachten
- Confidence und Severity immer nach `08_methods/Definitionen.md` setzen, nie nach Gefühl
- Annahmen/Inferenzen sichtbar von direkten Beobachtungen trennen
- Bei jeder Änderung an einer bestehenden Notiz: kurz kenntlich machen, was neu ist (z. B.
  `Confidence: Mittel → Hoch (P03 ergänzt)`), damit der Verlauf nachvollziehbar bleibt
- Sprache: Deutsch, konsistent mit dem restlichen Vault
- Bei Unsicherheit, ob etwas ein Duplikat ist: lieber nachfragen bzw. als Kommentar markieren,
  statt zu raten