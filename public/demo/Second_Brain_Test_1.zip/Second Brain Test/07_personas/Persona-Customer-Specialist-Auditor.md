---
typ: persona
name: "Stefanie — Die Customer Specialist (mit Audit)"
segment: Customer Specialist + Auditor
anzahl_interviews: 1
erstellt: "2026-07-08"
status: proto-persona
---

# Persona: Stefanie — Die Customer Specialist (mit Audit)

⚠️ **Vor dem Ausfüllen prüfen:** Basiert das auf mindestens 3 unterschiedlichen Interviews mit
konsistentem Muster? Wenn nein → Status auf `proto-persona` lassen und als Hypothese behandeln.
Siehe [[Definitionen]] Confidence-Kriterien — dieselbe Logik gilt hier.

→ **Status: proto-persona** — Basiert auf 1 Interview (INT-003). Alle Angaben sind vorläufige Hypothesen.

---

**Segment:** Customer Specialist + Auditor bei TÜV SÜD MHS (~60-70% CS, ~30-40% Audit)
**Basiert auf Interviews:** [[Interview-Stefanie-Weber-2026-07-08]]

## Kontext
Seit 4 Jahren bei TÜV SÜD. Dual-Rolle: primär Customer Specialist für einen großen Bestandskunden (hohe Projektlast, betreuungsintensiv) und einige kleinere Kunden; sekundär Auditorin (führt Audits vor Ort durch, arbeitet mit MACE Audit). Macht für Change Notifications auch "Significant Change"-Bewertungen (Decision of significant change). Bewertet keine technischen Dokumentationen selbst. Kommuniziert mit Kunden über UCI (bevorzugt) und E-Mail. Pflegt eigene Excel-Liste als Projekttracking-Workaround. Arbeitet eng mit Project Coordinator (PC) und Relationship Manager (RM) zusammen.

## Ziele
- Sofort sehen, was gerade von ihr erwartet wird ("bei wem liegt der Ball?")
- Weniger manuelle Bereinigung von Appendix-ABC-Daten bei Application Reviews
- Offizielle Kalkulationsvorlagen für alle Leistungsarten (Change Notifications, Supplier Audits)
- Einen Kanal für Kommunikation statt zwei (UCI + Email)
- Kunden besser durch den Antragsprozess führen (weniger Fehler bei Formblättern und ABC)

## Unterschiede zu anderen Personas
- **Vs. TD-Bewerter (INT-001):** Macht keinen TD-Assessment; koordiniert ihn nur. Mehr Kundenkontakt, mehr Prozess-Koordination, weniger Fachbeurteilung.
- **Vs. Dual-Bewerter (INT-002):** Mehr operativer CS-Fokus; weniger technische Tiefe beim Code-System. Stärker an Kunden-Workflow und Projekttracking interessiert.
- Einzige Persona mit explizitem Kostenkalkulationsaspekt (Stunden, Fees)
- Einzige Persona, die direkte Kundenfeedbacks zum Appendix ABC berichtet ("krieg ich regelmäßig als Rückmeldung")

## Zugehörige Themes
- [[Theme-Appendix-ABC-Datenqualitaet]]
- [[Theme-Prozesstransparenz-Projektuebersicht]]
- [[Theme-Tool-Fragmentierung]]
- [[Theme-Fehlende-Kalkulationsstandards]]

## Zugehörige Pain Points
- [[PP-02-Appendix-Codefehler]]
- [[PP-11-Projektstatus-Tracking-Fehlt]]
- [[PP-12-CS-PSE-Kein-Timeline-Aenderungsrecht]]
- [[PP-13-Fehlende-Offizielle-Kalkulationsvorlage]]
- [[PP-14-Fee-Regelung-Unklar]]
- [[PP-15-Appendix-ABC-Timing-Unklar-Change-Notification]]

## Zugehörige Needs
- [[Need-08-Responsibility-Visibility-Ball-Bei-Wem]]
- [[Need-09-Offizielle-Kalkulationsstandards]]
- [[Need-02-Zentraler-Produktdatenzugang]]
- [[Need-05-Systemische-Datenkonsistenz]]
