---
typ: persona
name: "Markus — Der erfahrene TD-Bewerter"
segment: TD-Bewerter
anzahl_interviews: 1
erstellt: "2026-07-08"
status: proto-persona
---

# Persona: Markus — Der erfahrene TD-Bewerter

⚠️ **Vor dem Ausfüllen prüfen:** Basiert das auf mindestens 3 unterschiedlichen Interviews mit
konsistentem Muster? Wenn nein → Status auf `proto-persona` lassen und als Hypothese behandeln.
Siehe [[Definitionen]] Confidence-Kriterien — dieselbe Logik gilt hier.

→ **Status: proto-persona** — Basiert auf 1 Interview (INT-001). Alle Angaben sind vorläufige Hypothesen.

---

**Segment:** TD-Bewerter (Technical Documentation Assessor) bei TÜV SÜD MHS
**Basiert auf Interviews:** [[Interview-Markus-Bauer-2026-06-30]]

## Kontext
Produktspezialist bei TÜV SÜD seit 2020. Bewertet technische Dokumentation von Medizinprodukten (MDR/MDR-IVDR) für die Produktzertifizierung — primär LoRIS- und Harris-Devices. Früher auch mit Application Management vertraut (als Project Handler tätig); heute Fokus auf Assessment-Phase. Kein direkter Kundenkontakt im Alltag — Schnittstelle ist der Customer Specialist. Arbeitet hybrid (Büro + Homeoffice), ausschließlich am PC/Laptop. Verwaltet parallele Projekte in PSE 2.0, priorisiert nach Deadlines.

## Ziele
- Effizienten, planbaren Arbeitstag ohne unerwartete Blockaden
- Projekte korrekt und fristgerecht abschließen (Assessment Report → Medici Upload → Zertifizierung)
- Faire, kapazitätsorientierte Projektzuteilung
- Schnell auf aktuelle Produktdaten und Working Instructions zugreifen — ohne Nachfragen
- Internationalen Projekten dieselbe Übersicht und Kontrollierbarkeit geben wie lokalen

## Zugehörige Themes
- [[Theme-Projektzuteilung-FCFS]]
- [[Theme-Appendix-ABC-Datenqualitaet]]
- [[Theme-Prozesstransparenz-Projektuebersicht]]
- [[Theme-Schnittstellen-Bottlenecks-International]]
- [[Theme-Timeline-Unzuverlaessigkeit]]
- [[Theme-Tool-Fragmentierung]]

## Zugehörige Pain Points
- [[PP-01-FCFS-Projektzuteilung]]
- [[PP-02-Appendix-Codefehler]]
- [[PP-03-Appendix-Versionszugang]]
- [[PP-04-Appendix-Supplier-Redundanz]]
- [[PP-05-Subcontract-Verzoegerung-International]]
- [[PP-06-PSE20-Datenqualitaet-International]]
- [[PP-07-Working-Instructions-Nachschlagen]]

## Zugehörige Needs
- [[Need-01-Effiziente-Projektzuteilung]]
- [[Need-02-Zentraler-Produktdatenzugang]]
- [[Need-03-Prozesskontextuelle-Guidance]]
- [[Need-04-Planbarkeit-Arbeitslast]]
- [[Need-05-Systemische-Datenkonsistenz]]
