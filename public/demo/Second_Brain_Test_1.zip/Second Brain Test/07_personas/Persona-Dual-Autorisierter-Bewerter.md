---
typ: persona
name: "Sebastian — Der Dual-autorisierte Bewerter/Auditor"
segment: Dual-autorisierter Bewerter/Auditor
anzahl_interviews: 1
erstellt: "2026-07-08"
status: proto-persona
---

# Persona: Sebastian — Der Dual-autorisierte Bewerter/Auditor

⚠️ **Vor dem Ausfüllen prüfen:** Basiert das auf mindestens 3 unterschiedlichen Interviews mit
konsistentem Muster? Wenn nein → Status auf `proto-persona` lassen und als Hypothese behandeln.
Siehe [[Definitionen]] Confidence-Kriterien — dieselbe Logik gilt hier.

→ **Status: proto-persona** — Basiert auf 1 Interview (INT-002, Prototyp-Evaluation). Alle Angaben sind vorläufige Hypothesen.

---

**Segment:** Dual-autorisierter Bewerter/Auditor bei TÜV SÜD MHS (Autorisierungen für TD Assessment + Audit; Ingenieurshintergrund)
**Basiert auf Interviews:** [[Interview-Sebastian-Reuter-P02]]

## Kontext
Senior Specialist mit dualer Autorisierung (MDA/MDN für TD-Assessment + MDT für Audit). Ingenieurshintergrund (mind. 4 Jahre Erfahrung mit Metallbearbeitungsthemen). Hat sowohl den Audit-Pfad als auch den TD-Assessment-Pfad im Blick. Kennt den Appendix-ABC-Prozess aus der Perspektive des Application Reviewers, nicht des operativen Ausfüllers (das macht der Customer Specialist). Arbeitet primär mit internen Tools (UCI, PSE 2.0) und kommuniziert mit Kunden über UCI/E-Mail. Evaluiert im Interview einen MACE-Application-Prototypen.

## Ziele
- Schneller überblicken, was ein neuer MDR-Auftrag erfordert (Audit? TD? Beides?) — ohne durch nicht-relevante Produktdetails scrollen zu müssen
- Klare Trennung der Informationen nach Pfad (Audit-relevante Codes & Sites vs. TD-relevante Produktfamilien)
- Projektstatus in Echtzeit verfolgen (intern, selektiv für kritische Projekte)
- Änderungen an Produktdaten nachvollziehen können — sowohl intern als auch optional gegenüber Kunden
- Ein Tool, das UCI ersetzt oder nahtlos integriert (kein zusätzlicher Kommunikationskanal)

## Unterschied zu Persona TD-Bewerter
- Breiteren Prozessüberblick (Audit + TD vs. nur TD)
- Fokus auf Codes/Sites für Feasibility Check & Audit-Planung statt auf Produktfamilien/Varianten
- Mehr Kunden-Schnittstelle: erkennt das regulatorische Risiko bei "on behalf"-Änderungen
- Explizit an Eskalationsmechanismen und Entscheidungsmessbarkeit interessiert

## Zugehörige Themes
- [[Theme-Appendix-ABC-Datenqualitaet]]
- [[Theme-Fehlende-Aenderungstransparenz]]
- [[Theme-Informationsarchitektur-Workflow-Mismatch]]
- [[Theme-Prozesstransparenz-Projektuebersicht]]
- [[Theme-Tool-Fragmentierung]]

## Zugehörige Pain Points
- [[PP-02-Appendix-Codefehler]]
- [[PP-09-Fehlende-Aenderungstransparenz]]
- [[PP-10-Informationsarchitektur-Workflow-Mismatch]]
- [[PP-11-Projektstatus-Tracking-Fehlt]]

## Zugehörige Needs
- [[Need-06-Aenderungstransparenz-Bidirektional]]
- [[Need-07-Selektives-Projektstatus-Tracking]]
- [[Need-02-Zentraler-Produktdatenzugang]]
