---
typ: pain-point
name: "Subcontract-Verzögerung bei internationalen Projekten blockiert Arbeitsbeginn"
theme: "Theme-Schnittstellen-Bottlenecks-International"
severity: Kritisch
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: Subcontract-Verzögerung bei internationalen Projekten blockiert Arbeitsbeginn

**Theme:** [[Theme-Schnittstellen-Bottlenecks-International]]
**Beschreibung:** Bei internationalen Projekten ist ein Subcontract-Dokument regulatorisch erforderlich, bevor gebucht und gearbeitet werden kann. Die Erstellung dieses Dokuments — eigentlich ein halbtägiger Aufwand — hat in einem konkreten Fall 3 Monate gedauert. Wiederholte Nachfragen blieben ohne Ergebnis.
**Trigger:** Projektstart bei internationalem Projekt; Bewerter kann nicht mit Arbeit beginnen ohne gültigen Subcontract.
**Impact:** Vollständige Blockade des Projektstarts (Severity: Kritisch); erhebliche Verzögerung für Kunden; Frustration und Kontrollverlust für den Bewerter.
**Workaround:** Kein effektiver Workaround — nur wiederholtes Nachfragen bei beteiligten Parteien (lokaler Project Handler, BSC/Global BSC).

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-001

**Repräsentative Zitate:**
> „ich hatte ein Projekt, da haben wir wiederholt immer wieder nachgefragt und wir haben kein Subcontract bekommen. Ohne den können wir eigentlich, wenn wir nicht keinen Auftrag haben, können nicht buchen können, können wir auch nicht arbeiten, eigentlich. Es gibt die Regulatoria vor, ich denk, da hat 3 Monate gebraucht, bis dann Subcontract da war, was eigentlich noch keine Ahnung an dem halben Tag gehen gehen sollte oder könnte." — INT-001

⚠️ **Hinweis (Severity vs. Confidence):** Dieser Pain Point hat Severity "Kritisch" bei Confidence "Niedrig" — ein einzelner, aber gravierender Bericht. Gezielte Anschlussforschung empfohlen, noch bevor höhere Confidence erreicht ist.

## Mögliche Opportunity
Strukturierter, SLA-gesteuerter Subcontract-Prozess mit Eskalationsautomatisierung und Fortschrittssichtbarkeit für den Bewerter.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
