---
typ: pain-point
name: "Informationsarchitektur zeigt Produktfamilien zuerst — Arbeitsfluss verlangt Codes zuerst"
theme: "Theme-Informationsarchitektur-Workflow-Mismatch"
severity: Mittel
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: Informationsarchitektur zeigt Produktfamilien zuerst — Arbeitsfluss verlangt Codes zuerst

**Theme:** [[Theme-Informationsarchitektur-Workflow-Mismatch]]
**Beschreibung:** Die MACE-Application-Screens zeigen Produktfamilien und Varianten als primäre Navigationsebene. Der tatsächliche Planungsfluss eines Bewerters/Auditors läuft aber von Technologie-Codes → Feasibility Check → Audit-Pfad vs. TD-Pfad → erst dann Produktfamilien. Die Screen-Logik zwingt den Nutzer, gegen seinen natürlichen Entscheidungsfluss zu arbeiten.
**Trigger:** Bewerter oder Auditor öffnet einen MDR-Zertifizierungsantrag und soll beurteilen, was zu tun ist.
**Impact:** Kognitive Reibung; relevante Informationen (MDT-Codes, Site-Daten) nicht sofort sichtbar; Gefahr falscher Priorisierung oder Fehleinschätzung des Aufwands ohne die richtigen Codes in der Übersicht.
**Workaround:** Manuelles Durchklicken in tiefere Ebenen, um an die Codes zu gelangen; intern gepflegte mentale Modelle / Erfahrungswissen kompensieren die Struktur.

⚠️ **Methodischer Hinweis:** Aus Prototyp-Evaluations-Sitzung (INT-002). Primär UI-Befund, aber mit zugrundeliegendem strukturellen Prozessargument. Weitere Interviews nötig zur Bestätigung.

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-002

**Repräsentative Zitate:**
> „In der Ansicht, die ich sehe, ist es ein bisschen umgedreht, wie der Arbeitsprozess läuft und zwar erstmal makroskopisch rauf zu gucken, bis man ins Mikroskopische geht. Was für Technologien habe ich, was für einen Produkttypen habe ich und dann kommt irgendwann, welches Produkt ist es eigentlich?" — INT-002

> „Es doppelt sich ja zwischen Characteristics of Product Family und den Codes. Die Charakteristiken sind die Codes." — INT-002

## Mögliche Opportunity
Rollenbasierte Standardansichten: Auditor sieht primär Codes/Sites (Audit-Pfad); TD-Bewerter sieht primär Produktfamilien/BUDIs. Oder: Ein einheitlicher Top-Level-View zeigt zuerst die Codes aggregiert über alle Produkte, dann Drill-down in einzelne Familien.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
