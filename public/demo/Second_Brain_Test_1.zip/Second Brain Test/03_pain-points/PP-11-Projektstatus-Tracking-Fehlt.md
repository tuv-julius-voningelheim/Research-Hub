---
typ: pain-point
name: "Projektstatus für interne Mitarbeitende nicht zentral sichtbar — kein Echtzeit-Tracking"
theme: "Theme-Prozesstransparenz-Projektuebersicht"
severity: Hoch
confidence: Mittel
erstellt: "2026-07-08"
---

# Pain Point: Projektstatus für interne Mitarbeitende nicht zentral sichtbar — kein Echtzeit-Tracking

**Theme:** [[Theme-Prozesstransparenz-Projektuebersicht]]
**Beschreibung:** Es gibt kein zentrales, echtzeit-aktuelles Dashboard, in dem TÜV-Mitarbeitende den Status ihrer Projekte verfolgen können. Status-Updates werden manuell kommuniziert oder erfordern aktives Nachfragen. Customer Specialists behelfen sich mit eigenen Excel-Listen; Bewerter/Auditoren wünschen DHL-ähnliches Tracking. Besonders kritisch bei High-Value-Projekten und bei hoher paralleler Projektlast.
**Trigger:** Statuswechsel passiert in einem Projekt; Mitarbeitende erfahren es nicht automatisch.
**Impact:** Unnötiger Kommunikationsaufwand; verspätete Reaktionen auf Statuswechsel; verpasste Eskalationsmöglichkeiten; keine Messbarkeit von Reaktionszeiten zwischen Anfrage und Entscheidung.
**Workaround:** Manuelle Statusabfragen via UCI, E-Mail oder Direktkommunikation; einzelne Schlüsselpersonen fungieren als informelle "Status-Hubs".

## Evidenz
**Evidence Count:** 3
**Interview-IDs:** INT-001, INT-002, INT-003

**Repräsentative Zitate:**
> „Tracking von Projektstatus ist mit Sicherheit eine wichtige Sache. wenn man das hier einbauen könnte wie bei einem DHL Paket, in welchem Status wir uns befinden." — INT-002

> „Die Zahlen zu erfassen... für Traceability auf jeden Fall gut." — INT-001

> „da kriege ich im Endeffekt selber eine Liste, die ist nicht schön, aber im Endeffekt einfach nur, wo ich auch wirklich so Kleinigkeiten einfach reinschreibe... damit ich nicht in Tagen wieder denke, was ist denn da der letzte Stand." — INT-003

> „gucke ich da schon irgendwie alle zwei Wochen mal, wenn ich denke, okay ich habe da jetzt schon länger nichts mehr gehört und was für ein Status ist." — INT-003

## Mögliche Opportunity
Echtzeit-Projektstatus-Dashboard (DHL-Modell) primär für interne Nutzer; selektive Freigabe für Kunden on demand; Eskalations-/Prio-Knopf mit Messbarkeit von Anfrage-bis-Entscheidung-Zeit.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
