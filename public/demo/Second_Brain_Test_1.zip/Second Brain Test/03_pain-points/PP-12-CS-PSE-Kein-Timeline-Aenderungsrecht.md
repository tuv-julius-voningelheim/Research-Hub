---
typ: pain-point
name: "CS kann PSE-Timelines nicht selbst anpassen — Abhängigkeit von PC erzeugt doppelte Arbeit"
theme: "Theme-Prozesstransparenz-Projektuebersicht"
severity: Mittel
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: CS kann PSE-Timelines nicht selbst anpassen — Abhängigkeit von PC erzeugt doppelte Arbeit

**Theme:** [[Theme-Prozesstransparenz-Projektuebersicht]]
**Beschreibung:** Wenn sich Timelines verschieben (z. B. Kundenrückmeldung verzögert sich), muss die Customer Specialist die Project Coordinator aktiv per E-Mail bitten, die PSE-Timelines anzupassen. Die PC erkennt Verschiebungen nicht selbst, auch wenn sie in CC-E-Mails stehen. Das führt dazu, dass CS Zeit verliert, um Informationen zu weiterzugeben, die die PC theoretisch bereits hat.
**Trigger:** Timeline-relevante Information trifft ein (z. B. Kundenrückmeldung verzögert); CS ist informiert, PC noch nicht.
**Impact:** Doppelte Kommunikationsarbeit; PSE bleibt veraltet wenn CS vergisst zu benachrichtigen; keine systemische Automatisierung der Timeline-Anpassung.
**Workaround:** CS schreibt manuelle E-Mail an PC ("Bitte alles anpassen"); oder CS akzeptiert, dass PSE nicht aktuell ist.

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-003

**Repräsentative Zitate:**
> „wünschte ich mir, wenn ich irgendwie... wenn sie in CC ist bei irgendeiner Mail und da deutlich hervorgeht, da verschiebt sich eine Timeline, dass sie das selbst erkennt und dann einfach eigenständig anpasst und ich nicht noch mal extra eine Mail an sie schreiben muss." — INT-003

> „wenn ich die Rechte hätte, in der Zeit, wo ich ihr dann noch mal die E-Mail schreibe, dass ihr die Timeline anfasst... könnt ich es einfach direkt selber updaten in dem Sinne. Das ist so ein bisschen, wo ich denke, das ist ein bisschen doppelte Arbeit einfach." — INT-003

## Mögliche Opportunity
Entweder: (a) CS bekommt direkte Editierrechte für Timelines eigener Projekte in PSE, oder (b) MACE Application übernimmt die Timeline-Steuerung und entlastet PSE von dieser Aufgabe komplett, oder (c) Automatische Erkennung von Timeline-Verschiebungen aus Kommunikationssignalen.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
