---
typ: pain-point
name: "Kein direkter Zugang zur aktuellsten Appendix-ABC-Version je Kunde"
theme: "Theme-Appendix-ABC-Datenqualitaet"
severity: Mittel
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: Kein direkter Zugang zur aktuellsten Appendix-ABC-Version je Kunde

**Theme:** [[Theme-Appendix-ABC-Datenqualitaet]]
**Beschreibung:** Es gibt keine zentrale, für alle zugängliche Ablage, wo Bewerter mit einem Klick die aktuellste Appendix-ABC-Version eines Kunden finden. Markus schaut zuerst in APC (Ablagesystem), fragt dann bei Customer Specialist oder Relationship Manager nach. Das funktioniert im Normalfall, erzeugt aber Abhängigkeiten von einzelnen Personen.
**Trigger:** Bewertungsslot beginnt; Bewerter benötigt aktuelle Produktdaten als Grundlage.
**Impact:** Zeitverlust durch Suche und Rückfragen; Risiko, mit einer veralteten Version zu arbeiten wenn niemand erreichbar ist; Abhängigkeit von Verfügbarkeit anderer Personen (Urlaub, Reaktionszeit).
**Workaround:** Nachfrage bei Customer Specialist oder Relationship Manager; manuelle Suche in APC.

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-001

**Repräsentative Zitate:**
> „wenn der Appendix ABC in der aktuellen Version für alle zugänglich wäre oder aufrufbar wäre... ich frag auch immer den Customer Specialist oder Relationship Manager, weil der weiß meistens, wo ist was ist der aktuellste, die aktuellste Version von Appendix A. B. C. Das kostet ein bisschen... wenn der gerade im Urlaub ist oder was, kann natürlich auch ein bisschen Zeit kosten" — INT-001

## Mögliche Opportunity
Zentrale versionierte Produktdatenbank je Kunde (Ersatz Appendix ABC) mit Zugriffsrechten für alle beteiligten TÜV-Rollen.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
