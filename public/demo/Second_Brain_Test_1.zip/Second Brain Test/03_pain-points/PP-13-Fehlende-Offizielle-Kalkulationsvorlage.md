---
typ: pain-point
name: Fehlende offizielle Kalkulationsvorlagen für Change Notifications und Supplier Audits
theme: Theme-Fehlende-Kalkulationsstandards
severity: Mittel
confidence: Niedrig
erstellt: 2026-07-08
---

# Pain Point: Fehlende offizielle Kalkulationsvorlagen für Change Notifications und Supplier Audits

**Theme:** [[Theme-Fehlende-Kalkulationsstandards]]
**Beschreibung:** Für TD Assessments und reguläre Audits gibt es standardisierte Berechnungsgrundlagen (PPS, Effort Calculation). Für Change Notifications und Supplier Audits hingegen existieren keine offiziell in ROXPA hinterlegten Kalkulationsvorlagen — nur eine inoffizielle Wiki-Seite, die nicht alle kennen und nicht alle nutzen. Das führt zu Schätzungen "aus dem Daumen".
**Trigger:** CS muss Stunden für eine Change Notification oder einen Supplier Audit kalkulieren.
**Impact:** Inkonsistente Kalkulationen zwischen verschiedenen CS-Mitarbeitenden; Risiko von Unter- oder Überkalkulation; zeitaufwändige Suche nach der richtigen Vorlage.
**Workaround:** Inoffizielle Wiki-Vorlage (nicht alle kennen sie); Schätzung nach Erfahrung; Nachfragen bei Kollegen.

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-003

**Repräsentative Zitate:**
> „Change Notifications, da gibt es nicht so eine richtig offizielle Vorlage... nichts, was in ROXPA ist und so ein bisschen inoffiziell läuft. fände ich tatsächlich eigentlich ganz cool, wenn es für alle Situationen irgendwie was offizielles gibt." — INT-003

## Mögliche Opportunity
Offizielle Kalkulationsvorlagen für alle Leistungsarten in ROXPA; oder Integration direkt in das neue MACE-Tool als geführter Kalkulationsassistent.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
