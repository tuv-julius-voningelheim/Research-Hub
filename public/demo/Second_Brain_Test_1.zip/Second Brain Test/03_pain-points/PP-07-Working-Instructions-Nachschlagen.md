---
typ: pain-point
name: "Aktuelle Working Instructions müssen für jeden Projekttyp manuell nachgeschlagen werden"
theme: "Theme-Prozesstransparenz-Projektuebersicht"
severity: Mittel
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: Aktuelle Working Instructions müssen für jeden Projekttyp manuell nachgeschlagen werden

**Theme:** [[Theme-Prozesstransparenz-Projektuebersicht]]
**Beschreibung:** Prozesse, Working Instructions und Reports ändern sich häufig — sowohl regulatorisch als auch intern. Markus muss bei jedem neuen Projekt die aktuell geltende Working Instruction manuell suchen und prüfen, ob sich etwas geändert hat. Dies gilt trotz 5,5 Jahren Erfahrung und betrifft alle Phasen (Application Management, Bewertung, Upload, Review).
**Trigger:** Start eines neuen Projekts, unabhängig vom Typ.
**Impact:** Wiederholter Zeitaufwand für das Nachschlagen; erhöhte Fehlerwahrscheinlichkeit wenn eine Änderung übersehen wird; kein einheitliches Handling der vielen Projekttypen (TD, Renewals, Change Notifications, Special Projects, Orphan Devices…).
**Workaround:** Manuelles Heraussuchen und Querlesen der Working Instructions vor jedem Projekt.

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-001

**Repräsentative Zitate:**
> „ich muss immer wieder die Working Instructions der aktuellen Version auch daneben legen, um die korrekt durchzuführen... Es kostet schon immer wieder Zeit, also ich muss mich immer wieder ein bisschen einlesen, hat sich etwas getan, gibt es Neuerungen" — INT-001

> „wir haben so viele verschiedene Projekttypen... Change Notifications auch über T. D. über Renewals, initiale Zertifizierungen, darum noch spezielle Special Projects... das ändert sich auch von außen. Regulatorisch gibt es auch mal wieder Änderungen" — INT-001

## Mögliche Opportunity
Kontextbezogene Prozessführung im Tool: Für den erkannten Projekttyp werden automatisch die aktuell gültigen Working Instructions, notwendigen Reports und Prozessschritte angezeigt.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
