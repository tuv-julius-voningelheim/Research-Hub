---
typ: pain-point
name: "Zertifizierungsphase (STC Review) für Kunden zeitlich nicht transparent"
theme: "Theme-Timeline-Unzuverlaessigkeit"
severity: Hoch
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: Zertifizierungsphase (STC Review) für Kunden zeitlich nicht transparent

**Theme:** [[Theme-Timeline-Unzuverlaessigkeit]]
**Beschreibung:** Der letzte Prozessschritt vor der Zertifizierung — der Review durch STC (Certification Body) oder LTR — ist für Kunden am wenigsten zeitlich vorhersehbar. Obwohl ein Servicemodell-Zeitrahmen existiert, entstehen häufig Rückfragen und Verschiebungen. Kunden, die bereits alle Mängel behoben haben und auf das Zertifikat warten, erhalten in dieser Phase kaum proaktive Kommunikation.
**Trigger:** Alle Deficiencies sind geschlossen; Projekt geht zur STC/LTR-Review über.
**Impact:** Frustration und Unsicherheit beim Kunden; Planungsrisiken für den Hersteller (Markteinführung); Vertrauensverlust gegenüber TÜV als verlässlichem Partner.
**Workaround:** Kein strukturierter Workaround — Customer Specialist oder Relationship Manager kommunizieren ggf. informell.

## Evidenz
**Evidence Count:** 1 (Perspektive eines TD-Bewerters über Kundenerfahrung — indirekt)
**Interview-IDs:** INT-001

**Repräsentative Zitate:**
> „ich denke, der größte Pain Point für Kunden ist, wenn wenn die Timeline nicht eingehalten werden, weil der Kunde, der muss zuverlässig wissen, wann wann ist jetzt eine Bewertung fertig... dieser letzte Schritt quasi vor der Zertifizierung, wenn es dann im Review ist durch STC... Da war zwar auch eine Timeline in unseren Servicemodellen, aber da da kommt es oft zu Rückfragen quasi, dann verschiebt sich oder verlängert sich der Slot." — INT-001

⚠️ **Methodischer Hinweis:** Dies ist eine Fremdbeobachtung (TD-Bewerter über Kunden), keine direkte Kundenaussage. Confidence bleibt Niedrig bis Kundensicht direkt erhoben wird.

## Mögliche Opportunity
Proaktive, statusgebundene Kommunikation an Kunden in der STC-Review-Phase; Transparenz über verbleibende Schritte und realistische Timeline-Prognosen.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
