---
typ: pain-point
name: "Kundenfehler in Appendix-ABC-Codes erzeugen kostspieliges Hin-und-Her"
theme: "Theme-Appendix-ABC-Datenqualitaet"
severity: Hoch
confidence: Hoch
erstellt: "2026-07-08"
---

# Pain Point: Kundenfehler in Appendix-ABC-Codes erzeugen kostspieliges Hin-und-Her

**Theme:** [[Theme-Appendix-ABC-Datenqualitaet]]
**Beschreibung:** Kunden füllen den Appendix ABC — insbesondere die Produktcodes — fehlerhaft aus: Codes fehlen, sind falsch zugewiesen oder nicht klar für den Kunden selbst. TÜV-Mitarbeitende müssen dann Rückfragen stellen oder die Fehler selbst korrigieren. Das kostet Zeit und kann sich über mehrere Runden ziehen.
**Trigger:** Appendix ABC wird vom Kunden eingereicht; beim Application Review oder Assessment-Start fallen Inkonsistenzen auf.
**Impact:** Verzögerungen im Application Management; mehrere Kommunikationsrunden erforderlich; wenn Fehler erst in der Bewertungsphase auffallen, müssen Prozesse rückwärts korrigiert werden.
**Workaround:** Bewerter oder Application Reviewer korrigieren offensichtliche Fehler selbst (als STC/Senior Technical Certifier möglich); Rückfragen an Kunden bei Unklarheiten.

## Evidenz
**Evidence Count:** 2
**Interview-IDs:** INT-001, INT-002

**Repräsentative Zitate:**
> „Das ist ein komplexes Dokument natürlich der Appendix A. B. C. auch verschiedenste Produkte aufgeführt werden... es kommen immer noch zu Rückfragen, auf jeden Fall. Manchmal ist auch nicht so ganz klar, ist der Code jetzt relevant für das Produkt oder nicht... da geht das bisschen hin und her und das kann viel Zeit kosten." — INT-001

> „wenn es wirklich für uns klar ist, aus anderen Informationen, dass der Code einfach falsch ist und der andere wichtig wär, dass ich das quasi auch selber verbessern kann, mich selber als Autorun eintragen kann" — INT-001

> „Der normale Weg ist 'Hey, das ist mein Produkt' und dann sagen wir 'Füll mal bitte den Appendix ABC aus, die versuchen das nach dem Best Guest zu machen, ohne zu wissen, warum wir was anfragen.'" — INT-002

> „Diese Sichtweise, über die wir so standardmäßig reden, ist für Legalhersteller eigentlich eine riesen Blackbox. Also die verstehen gar nicht, was wollen die mit MDT und was passiert mit MDS und wann ist was." — INT-002

> „gerade im Appendix ABC, da verliere ich glaube ich am meisten Zeit... eigentlich ist jede Application, die mir mein Großkunde schickt, dauert extrem lange, weil in dieser Bearbeitung von der Application, im Endeffekt ich die Daten aufräume." — INT-003

> „es fällt mir während des Assessments so wann Sachen auf wie, es gibt hier in einer Basic UDI verschiedene intended users. Dürfen sie eigentlich gar nicht haben. Solche Sachen könnte man ja auch elektronisch im Idealfall irgendwie schon vorab irgendwie klären." — INT-003

**Interview-IDs:** INT-001, INT-002, INT-003 | **Evidence Count:** 3

## Mögliche Opportunity
Contextbezogene Code-Hilfen, Beispiele und MDCG-Guidance-Links direkt im Eingabeformular; automatische Plausibilitätsprüfung aus Produktbeschreibung (Partial Automation als erster Filter, Experte validiert).

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
