---
typ: pain-point
name: "PSE 2.0 bei internationalen Projekten ohne Übersichtsfunktion genutzt"
theme: "Theme-Prozesstransparenz-Projektuebersicht"
severity: Hoch
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: PSE 2.0 bei internationalen Projekten ohne Übersichtsfunktion genutzt

**Theme:** [[Theme-Prozesstransparenz-Projektuebersicht]]
**Beschreibung:** Internationale Teams (IBSC/Global BSC) nutzen PSE 2.0 ausschließlich zur Stundenbuchung, nicht als Projektplanungs- und Übersichtsinstrument. Für den TD-Bewerter bedeutet das: Kein Projektphasenstatus, keine aktuellen Timelines, keine offenen To-Dos sichtbar — obwohl dieselbe Plattform genutzt wird.
**Trigger:** Bewerter öffnet ein internationales Projekt in PSE 2.0 und sieht nur formale Tasks, aber keine inhaltliche Projektstruktur.
**Impact:** Vollständiger Verlust der Projektübersicht; Bewerter muss Informationen individuell erfragen; erhöhtes Risiko von Missverständnissen und verpassten Deadlines.
**Workaround:** Direkte Kommunikation mit beteiligten Parteien (E-Mail, Teams) — zeitaufwändig und abhängig von Reaktionszeiten.

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-001

**Repräsentative Zitate:**
> „die legen die Tasks nur an, quasi um damit man sie auch buchen können... nicht um irgendeine Ablaufplanung oder Übersicht zu ermöglichen, ne. Und wenn das so gehandhabt wird, dann habe ich eigentlich keinerlei Übersicht mehr." — INT-001

## Mögliche Opportunity
Tool-Governance mit verbindlichen Mindest-Nutzungsstandards für PSE 2.0, oder Überführung der Projektübersicht in MACE Application mit klarer Rollentrennung zu PSE (nur Buchung).

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
