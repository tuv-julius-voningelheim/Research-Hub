---
typ: pain-point
name: "Kunden wissen nicht, wann Appendix ABC bei Change Notification zu aktualisieren ist"
theme: "Theme-Appendix-ABC-Datenqualitaet"
severity: Mittel
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: Kunden wissen nicht, wann Appendix ABC bei Change Notification zu aktualisieren ist

**Theme:** [[Theme-Appendix-ABC-Datenqualitaet]]
**Beschreibung:** Im Change-Notification-Prozess ist für Kunden unklar, wann der Appendix ABC aktualisiert werden soll: Schon bei Einreichung der Change Application (vorher), oder erst wenn der Change von TÜV akzeptiert wurde (nachher)? Der Customer Specialist muss diese Frage immer wieder von Neuem erklären. Das führt dazu, dass Kunden den ABC oft ohne korrekte Änderungen einreichen oder ihn ganz weglassen.
**Trigger:** Kunde reicht eine Change Notification Application ein; hat den Appendix ABC nicht oder falsch aktualisiert.
**Impact:** CS muss den Kunden zur Nachkorrektur auffordern; Verzögerung im Application-Prozess; wiederholter Erklärungsaufwand für CS.
**Workaround:** CS erklärt es dem Kunden bei jeder Einreichung erneut; nimmt die Korrektur teils selbst vor.

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-003

**Repräsentative Zitate:**
> „der Augenblick so ganz bewusst ist, wann ändere ich diesen Appendix ABC? Erst wenn der Change quasi von uns akzeptiert ist oder schon am Anfang, das sind so typische Sachen, die ich immer wieder erklären muss." — INT-003

> „meistens nicht so, dass sie da überhaupt den Appendix ABC mitschicken, geschweige denn da schon die Änderung irgendwie drin haben." — INT-003

## Mögliche Opportunity
Geführter Antragsprozess (Wizard) mit kontextueller Erklärung, wann welche Datei zu aktualisieren ist; oder Validierungsregel, die prüft ob der ABC-Status "Device in Change" bereits für das betroffene Produkt gesetzt ist.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
