---
typ: pain-point
name: "Fee-Regelung unklar — CS, PC und RM wissen nicht, welche Gebühren wann fällig sind"
theme: "Theme-Fehlende-Kalkulationsstandards"
severity: Mittel
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: Fee-Regelung unklar — CS, PC und RM wissen nicht, welche Gebühren wann fällig sind

**Theme:** [[Theme-Fehlende-Kalkulationsstandards]]
**Beschreibung:** Es ist unklar, wann welche Fees (z. B. Notified Body Review Fee, Certification Review Fee) zu einem Angebot hinzuzufügen sind — insbesondere bei Change Notifications und Special Audits. Weder CS, PC noch RM können diese Frage verlässlich beantworten. Die Entscheidung läuft auf "Irgendwas entscheiden" hinaus; da sich Kunden bisher nicht beschwert haben, besteht kein akuter Druck, dies zu klären.
**Trigger:** CS erstellt Kalkulation und muss entscheiden, ob eine bestimmte Fee applicable ist.
**Impact:** Inkonsistente Angebote; potenzielle Über- oder Unterabrechnung; Reputationsrisiko wenn Kunden es bemerken; Zeitverlust durch Rückfragen bei PC/RM.
**Workaround:** Nachfragen bei PC oder RM; wenn niemand Bescheid weiß: Entscheidung nach eigenem Ermessen.

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-003

**Repräsentative Zitate:**
> „anscheinend nie ganz klar, jetzt mit diesen Gebühren. Also brauche ich eine Multiplied Body Review Fee, brauche ich eine Certification Review Fee... das wissen beide einfach selber nicht und dann entscheiden sie einfach irgendwas." — INT-003

> „Ich habe da auch rumgefragt, meine eine PC hat auch Versicherung gefragt, das war alles ein bisschen, man wusste da so richtig Bescheid. weil die machen das einfach irgendwie und beschweren tut sich dann am Ende ja auch keiner." — INT-003

## Mögliche Opportunity
Entscheidungsbaum für Fee-Zuordnung direkt im Kalkulationsschritt des neuen Tools; oder zentrales, offiziell gepflegtes Fee-Regelwerk in ROXPA.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
