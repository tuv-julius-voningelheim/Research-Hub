---
typ: pain-point
name: "Keine Änderungstransparenz — Kunde sieht TÜV-Korrekturen nicht, kein Audit Trail"
theme: "Theme-Fehlende-Aenderungstransparenz"
severity: Hoch
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: Keine Änderungstransparenz — Kunde sieht TÜV-Korrekturen nicht, kein Audit Trail

**Theme:** [[Theme-Fehlende-Aenderungstransparenz]]
**Beschreibung:** Wenn TÜV-Mitarbeitende Datenpunkte im Appendix ABC ändern (z. B. Codes korrigieren, da der Kunde sie falsch eingetragen hat), gibt es kein System, das: (a) festhält wer wann was geändert hat, (b) den Kunden informiert und (c) eine Rückmeldung oder Bestätigung des Kunden ermöglicht. Das führt dazu, dass inkorrekte Systeme "dumm" bleiben — Kunden wiederholen Fehler, weil sie keine Rückmeldung über Korrekturen bekommen.
**Trigger:** TÜV korrigiert Kundendaten (Codes, Produktinformationen) im laufenden Prozess.
**Impact:** Kein Lerneffekt auf Kundenseite; Fehler wiederholen sich; regulatorisches Risiko (TÜV handelt "on behalf" ohne explizite Zustimmung); fehlende Rückverfolgbarkeit im Fall von Audit oder Dispute.
**Workaround:** Informelle Kommunikation via UCI oder E-Mail vor jeder Änderung; keine systemische Lösung vorhanden.

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-002

**Repräsentative Zitate:**
> „Ein Riesenproblem in unserem System ist die fehlende Transparenz von Änderungen. Wann wird welche Änderung wie gemacht, wer hat sie gemacht, wie wird sie gehighlightet, der Kunde sieht nicht, wenn wir was anpassen, dementsprechend hat man 'ne Verdummung von einem System oder eher gesagt, keine Verbesserung von einem dummen System." — INT-002

> „Das ist grob schlicht nicht falsch, weil es kann einfach anders sein. Ja, das sind verschiedene Perspektiven, die beide bedient werden können und auch müssten in manchen Fällen." — INT-002

## Mögliche Opportunity
Änderungsprotokoll mit Zeitstempel, Nutzer und Begründungsfeld; optionaler Benachrichtigungs-Toggle ("Möchte ich, dass der Kunde von dieser Änderung mitbekommt?"); Specification-Request-Funktion für formale Klärungsanfragen an den Kunden.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
