---
typ: pain-point
name: "Supplier-Informationen in Appendix ABC redundant und inkonsistent"
theme: "Theme-Appendix-ABC-Datenqualitaet"
severity: Mittel
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: Supplier-Informationen in Appendix ABC redundant und inkonsistent

**Theme:** [[Theme-Appendix-ABC-Datenqualitaet]]
**Beschreibung:** Die Appendix ABC enthält Supplier-Angaben sowohl in Sheet 1 (allgemein je Produkt) als auch in späteren Sheets (Sheet A.2/A.3 für spezifische Module wie Sterilisation). Diese redundanten Einträge sind oft widersprüchlich — z. B. Supplier in Sheet 1 nicht genannt, aber in A.3 schon. Das erzeugt Rückfragen: Fehler oder Absicht?
**Trigger:** Application Review oder Bewertung; Bewerter gleicht Supplier-Angaben über Sheets ab.
**Impact:** Rückfragen an Kunden; Unsicherheit über korrekte Datenbasis; Zeitverlust bei der Klärung.
**Workaround:** Manueller Abgleich über mehrere Sheets; Rückfrage an Kunden wenn widersprüchlich.

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-001

**Repräsentative Zitate:**
> „gibt so ein paar Redundanzen, also im Sheet 1 zum Beispiel... Die gleiche Information oder ähnlich habe ich aber dann noch mal in diesen Sheets dahinter, A. Punkt 2 oder A. Punkt 3 zum Beispiel für Sterilization... und die sind oft widersprüchlich und da kommt schon mal zu fragen, ja, war das jetzt 'n Fehler vom Kunden oder 'n Missverständnis" — INT-001

## Mögliche Opportunity
Datenbankstruktur mit verknüpften Einträgen statt redundanter Sheets — Supplier wird einmal pro Produkt gepflegt und automatisch in alle Module referenziert (Single Source of Truth).

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
