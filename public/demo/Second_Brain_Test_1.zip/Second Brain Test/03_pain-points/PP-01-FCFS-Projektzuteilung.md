---
typ: pain-point
name: "FCFS-Projektzuteilung erzwingt permanente Verfügbarkeitsüberwachung"
theme: "Theme-Projektzuteilung-FCFS"
severity: Hoch
confidence: Niedrig
erstellt: "2026-07-08"
---

# Pain Point: FCFS-Projektzuteilung erzwingt permanente Verfügbarkeitsüberwachung

**Theme:** [[Theme-Projektzuteilung-FCFS]]
**Beschreibung:** Projekte werden nach First-Come-First-Serve vergeben: Wer als Erstes auf die Medici/Wiki-Anfrage klickt, erhält das Projekt. Da Markus oft am Ende eines vollen Arbeitstages erstmals nachschaut, sind Projekte meist schon vergeben. Das System bevorzugt Mitarbeitende, die gerade nichts anderes tun — nicht die mit der passendsten Kapazität oder Expertise.
**Trigger:** Neue Projektanfrage wird im System geöffnet; Benachrichtigung geht an alle qualifizierten Bewerter gleichzeitig.
**Impact:** Ungleiche Arbeitslastverteilung; fehlende Kontrollierbarkeit der eigenen Auslastungsplanung; strukturelle Benachteiligung von Bewertern, die gerade intensiv an anderen Projekten arbeiten.
**Workaround:** Keiner möglich — wer nicht rechtzeitig klickt, bekommt das Projekt nicht. Relationship Manager können gezielt anfragen, aber das ist die Ausnahme.

## Evidenz
**Evidence Count:** 1
**Interview-IDs:** INT-001

**Repräsentative Zitate:**
> „Das geht auch auf Zeit quasi. Also der als erstes First Come First Serve Prinzip quasi, das ist schon mal ein erster Punkt der schwierig ist ja. Weil meistens komme ich erst wenn ich am Projekt sitz sag ich mal am Ende des Tages dazu da reinzuschauen am nächsten Tag und dann merkt man eigentlich dass also wenn man nicht in den ersten ein, zwei, drei oder fünf Minuten klickt ist es eigentlich schon weg." — INT-001

> „Ich denke das könnte auch schon mal ein Punkt sein der zu einer Ungleichverteilung von der Arbeitslast führt." — INT-001

## Mögliche Opportunity
24-Stunden-Zeitfenster für Rückmeldung, danach kapazitäts- und expertisebasierte Zuteilung durch Scheduling-Team oder Algorithmus — direkt vom Nutzer vorgeschlagen.

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.
