---
typ: need
name: "Selektives Projektstatus-Tracking (intern first, Kunde on demand)"
kategorie: Funktional
theme: "Theme-Prozesstransparenz-Projektuebersicht"
erstellt: "2026-07-08"
---

# Need: Selektives Projektstatus-Tracking (intern first, Kunde on demand)

**Kategorie:** Funktional
**Beschreibung:** Interne TÜV-Mitarbeitende brauchen ein Echtzeit-Statustracking für ihre Projekte — primär für sich selbst (nicht für den Kunden). Dabei soll das Tracking selektiv konfigurierbar sein: Nicht jede Statusänderung soll alle Benachrichtigen, sondern nur die als kritisch markierten Projekte (High-Value, Dedicated Services). Der Kundenzugang zum Tracking soll optional und kontrolliert freischaltbar sein.
**Zugehöriges Theme:** [[Theme-Prozesstransparenz-Projektuebersicht]]

## Evidenz
**Repräsentative Zitate:**

> „Tracking von Projektstatus ist mit Sicherheit eine wichtige Sache. wenn man das hier einbauen könnte wie bei einem DHL Paket, in welchem Status wir uns befinden, wo das Paket sich gerade befindet." — INT-002

> „Für mich noch viel besser als für den Kunden ehrlich gesagt. Und das freizugeben für den Kunden on demand." — INT-002

> „Vor allem dedicated Services... alle High Price, High Volume... auch, dass mein Customer Specialist das auswählt, was er als sehr kritisch erachtet, dass er mich informieren kann." — INT-002
