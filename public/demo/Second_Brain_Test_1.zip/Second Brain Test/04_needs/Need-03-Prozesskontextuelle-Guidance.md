---
typ: need
name: "Kontextuelle Prozessführung je Projekttyp im Tool"
kategorie: Funktional
theme: "Theme-Prozesstransparenz-Projektuebersicht"
erstellt: "2026-07-08"
---

# Need: Kontextuelle Prozessführung je Projekttyp im Tool

**Kategorie:** Funktional
**Beschreibung:** Bei so vielen Projekttypen (TD, Renewals, Change Notifications, Special Projects, Orphan Devices…) und häufigen regulatorischen sowie internen Prozessänderungen brauchen Bewerter ein Tool, das ihnen für das aktuelle Projekt automatisch anzeigt: Welche Working Instructions, welche Reports, welche Prozessschritte gelten gerade für diesen Typ?
**Zugehöriges Theme:** [[Theme-Prozesstransparenz-Projektuebersicht]]

## Evidenz
**Repräsentative Zitate:**

> „wenn in einem Tool dann die immer angezeigt werden würde für dieses Projekt... welche Prozesse, welche Procedures quasi, welche Working Instructions, welche Reports brauche ich jetzt genau für dieses Projekt. Ich denke, das kann sehr, sehr hilfreich sein, ja." — INT-001

> „jetzt auch schon ja 2020 fünfeinhalb Jahre dabei, aber wie gesagt, ich muss mich jedes Mal auch wieder updaten, neu einlesen, ja." — INT-001
