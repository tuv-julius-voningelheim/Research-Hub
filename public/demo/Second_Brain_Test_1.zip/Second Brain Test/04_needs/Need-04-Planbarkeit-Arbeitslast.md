---
typ: need
name: "Planbare, kontrollierbare Arbeitslast"
kategorie: Emotional
theme: "Theme-Projektzuteilung-FCFS"
erstellt: "2026-07-08"
---

# Need: Planbare, kontrollierbare Arbeitslast

**Kategorie:** Emotional
**Beschreibung:** Markus will seine Arbeitslast aktiv planen können — wissen, was wann auf ihn zukommt, und die eigene Kapazität fair einschätzen können. Das FCFS-System entzieht ihm diese Kontrolle: Er kann nicht beeinflussen, was er wann bekommt, und fühlt sich strukturell benachteiligt wenn er gerade in einem intensiven Projekt steckt.
**Zugehöriges Theme:** [[Theme-Projektzuteilung-FCFS]]

## Evidenz
**Repräsentative Zitate:**

> „Das geht auch auf Zeit quasi... wenn man nicht in den ersten ein, zwei, drei oder fünf Minuten klickt ist es eigentlich schon weg." — INT-001

> „Ich denke das könnte auch schon mal ein Punkt sein der zu einer Ungleichverteilung von der Arbeitslast führt." — INT-001
