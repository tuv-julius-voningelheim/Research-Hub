---
typ: need
name: "Effiziente und faire Projektzuteilung nach Kapazität und Expertise"
kategorie: Funktional
theme: "Theme-Projektzuteilung-FCFS"
erstellt: "2026-07-08"
---

# Need: Effiziente und faire Projektzuteilung nach Kapazität und Expertise

**Kategorie:** Funktional
**Beschreibung:** Bewerter brauchen ein Zuteilungssystem, das relevante Faktoren berücksichtigt: aktuelle Auslastung, vorhandene Autorisierungen für das Produkt, und ggf. bestehende Kundenbeziehung — statt reinem Reaktionsgeschwindigkeitswettbewerb.
**Zugehöriges Theme:** [[Theme-Projektzuteilung-FCFS]]

## Evidenz
**Repräsentative Zitate:**

> „auf jeden Fall besser als First Come for Surfer schon mal 'n Zeitfenster, wir haben meinten meine erste Idee, sag ich mal 24 Stunden. und dann sieht man, wer klickt und dann muss man entscheiden... wer da wirklich am wenigsten Auslastung von den Leuten, die dann zugesagt haben" — INT-001
