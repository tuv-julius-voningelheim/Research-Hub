---
typ: need
name: "Direkter Zugang zu aktuellen Produktdaten je Kunde"
kategorie: Funktional
theme: "Theme-Appendix-ABC-Datenqualitaet"
erstellt: "2026-07-08"
---

# Need: Direkter Zugang zu aktuellen Produktdaten je Kunde

**Kategorie:** Funktional
**Beschreibung:** Bewerter und Application Manager brauchen mit einem Klick Zugang zur jeweils aktuellsten, vollständigen Produktdatengrundlage eines Kunden (Codes, BUDIs, Module, Supplier) — ohne Nachfragen, ohne Suche in verteilten Ablagesystemen.
**Zugehöriges Theme:** [[Theme-Appendix-ABC-Datenqualitaet]]

## Evidenz
**Repräsentative Zitate:**

> „wenn der Appendix ABC in der aktuellen Version für alle zugänglich wäre oder aufrufbar wäre... wenn man da wirklich 'ne Plattform hätte, wo wo jeder Zugang hat, wo jeder die aktuelle Version findet, das das wäre natürlich super, ja." — INT-001
