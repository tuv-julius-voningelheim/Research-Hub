---
typ: need
name: "Bidirektionale Änderungstransparenz mit optionaler Kundenbenachrichtigung"
kategorie: Funktional
theme: "Theme-Fehlende-Aenderungstransparenz"
erstellt: "2026-07-08"
---

# Need: Bidirektionale Änderungstransparenz mit optionaler Kundenbenachrichtigung

**Kategorie:** Funktional
**Beschreibung:** TÜV-Mitarbeitende brauchen ein Änderungsprotokoll (wer hat was wann geändert, warum), das intern vollständig sichtbar ist. Ergänzend muss es möglich sein, den Kunden gezielt und kontrolliert über Änderungen zu informieren — mit einem Benachrichtigungs-Toggle pro Änderung ("Möchte ich, dass der Kunde das mitbekommt?"). Nicht jede Änderung muss an den Kunden gehen; aber alle müssen protokolliert sein.
**Zugehöriges Theme:** [[Theme-Fehlende-Aenderungstransparenz]]

## Evidenz
**Repräsentative Zitate:**

> „Ein Riesenproblem in unserem System ist die fehlende Transparenz von Änderungen. Wann wird welche Änderung wie gemacht, wer hat sie gemacht, wie wird sie gehighlightet, der Kunde sieht nicht, wenn wir was anpassen" — INT-002

> „Möchte ich, dass der Kunde von dieser Änderung mitbekommt oder nicht? Also ein Tick-off wäre schon smart." — INT-002
