---
typ: need
name: "Systemische Sicherstellung von Datenkonsistenz (statt Personenabhängigkeit)"
kategorie: Latent
theme: "Theme-Appendix-ABC-Datenqualitaet"
erstellt: "2026-07-08"
---

# Need: Systemische Sicherstellung von Datenkonsistenz (statt Personenabhängigkeit)

**Kategorie:** Latent
**Beschreibung:** Nicht direkt ausgesprochen, aber aus der Evidenz ableitbar: Der aktuelle Prozess verlässt sich für Datenqualität (Appendix ABC korrekt ausgefüllt, PSE 2.0 gepflegt, aktuellste Version verfügbar) auf die Disziplin und Verfügbarkeit einzelner Personen. Markus beschreibt mehrfach Workarounds, die funktionieren „wenn alles gut läuft" — und scheitern, wenn jemand im Urlaub ist, eine andere Nutzungsgewohnheit hat oder in einer anderen Region sitzt. Das eigentliche Bedürfnis ist ein System, das Konsistenz strukturell sicherstellt.

> **Hinweis (Latent):** Dies ist eine Inferenz, keine direkte Aussage von Markus. Basiert auf der Häufung der Workaround-Beschreibungen und dem Muster „funktioniert wenn gepflegt, versagt wenn nicht".

**Zugehöriges Theme:** [[Theme-Appendix-ABC-Datenqualitaet]], [[Theme-Prozesstransparenz-Projektuebersicht]]

## Evidenz
**Repräsentative Zitate:**

> „wenn die Datenqualität gut ist, wie es im PSE 20 eingetragen ist, dann sehe ich da eigentlich alles... Wenn das so gehandhabt wird, dann habe ich eigentlich keinerlei Übersicht mehr." — INT-001

> „ich frag auch immer den Customer Specialist oder Relationship Manager, weil der weiß meistens, wo ist was ist der aktuellste, die aktuellste Version von Appendix A. B. C. Das kostet ein bisschen... wenn der gerade im Urlaub ist oder was" — INT-001
