---
typ: need
name: "Offizielle, werkzeuggestützte Kalkulationsstandards für alle Leistungsarten"
kategorie: Funktional
theme: "Theme-Fehlende-Kalkulationsstandards"
erstellt: "2026-07-08"
---

# Need: Offizielle, werkzeuggestützte Kalkulationsstandards für alle Leistungsarten

**Kategorie:** Funktional
**Beschreibung:** Customer Specialists brauchen für jeden Leistungstyp (TD Assessment, Audit, Change Notification, Supplier Audit, Special Audit, Technical Meeting usw.) eine verbindliche, in das Tool integrierte Berechnungsgrundlage — inklusive klarer Regeln, wann welche Fees applicable sind. Das ersetzt inoffizielle Wiki-Vorlagen und Bauchgefühlsentscheidungen durch einen transparenten, nachvollziehbaren Kalkulationsprozess.
**Zugehöriges Theme:** [[Theme-Fehlende-Kalkulationsstandards]]

## Evidenz
**Repräsentative Zitate:**

> „fände ich tatsächlich eigentlich ganz cool, wenn es für alle Situationen irgendwie was offizielles gibt." — INT-003

> „anscheinend nie ganz klar, jetzt mit diesen Gebühren... das wissen beide einfach selber nicht und dann entscheiden sie einfach irgendwas." — INT-003
