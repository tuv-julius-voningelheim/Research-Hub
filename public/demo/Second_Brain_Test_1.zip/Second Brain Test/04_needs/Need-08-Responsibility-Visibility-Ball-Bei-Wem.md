---
typ: need
name: "Sichtbarkeit 'bei wem liegt der Ball' — Verantwortungsklarheit in Echtzeit"
kategorie: Funktional
theme: "Theme-Prozesstransparenz-Projektuebersicht"
erstellt: "2026-07-08"
---

# Need: Sichtbarkeit "bei wem liegt der Ball" — Verantwortungsklarheit in Echtzeit

**Kategorie:** Funktional
**Beschreibung:** Mitarbeitende (Customer Specialists, Bewerter, Auditoren) brauchen sofortige Klarheit darüber, ob sie aktuell aktiv werden müssen oder ob ein anderer Prozessschritt im Gange ist. Die Frage "Liegt gerade eine Aufgabe bei mir oder nicht?" soll nicht durch manuelle Nachfragen oder periodisches Durchsehen einer Excel-Liste beantwortet werden müssen, sondern direkt im Tool sichtbar sein — ergänzt durch automatische Benachrichtigungen wenn der Ball weitergereicht wird.
**Zugehöriges Theme:** [[Theme-Prozesstransparenz-Projektuebersicht]]

## Evidenz
**Repräsentative Zitate:**

> „das wäre cool, dass man so das so sehen könnte, okay bei wem liegt gerade der Ball in dem Sinne und muss ich überhaupt irgendwas machen, muss ich aktiv werden." — INT-003

> „dass dieses Nachverfolgen vielleicht auch gar nicht mehr nötig ist, weil der andere dann ja auch sieht, bei ihm liegt der Ball und dann vielleicht von alleine irgendwie eine Mail kriegt." — INT-003

> „muss ich jetzt 'ne Kalkulation... hängt das jetzt gerade an mir... oder hängt das dann an an meiner P. C., dass sie jetzt das Angebot erstellen muss, ist das rausgegangen." — INT-003
