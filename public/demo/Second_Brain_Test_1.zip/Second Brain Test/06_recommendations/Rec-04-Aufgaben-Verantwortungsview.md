---
typ: recommendation
name: "Aufgaben- und Verantwortungsview — 'Wer hat den Ball?' als zentrales UX-Prinzip"
priority: Hoch
erstellt: "2026-07-08"
---

# Recommendation: Aufgaben- und Verantwortungsview — "Wer hat den Ball?" als zentrales UX-Prinzip

**Empfehlung:** MACE Application soll für jeden Mitarbeitenden eine persönliche Aufgabensicht bieten, die auf einen Blick zeigt: (1) Welche Projekte erfordern gerade meine Aktion? (2) Bei welchen Projekten liegt der Ball woanders (Kunde, PC, TD-Bewerter, etc.)? Diese "Wer hat den Ball?"-Logik soll durch automatische Benachrichtigungen ergänzt werden, wenn der Ball weitergereicht wird — damit manuelles Nachfragen und periodisches Excel-Durchsuchen entfällt. Für Customer Specialists soll zusätzlich sichtbar sein, ob offene Kalkulationen, Angebote oder Kundenrückmeldungen ausstehen.

**Evidenz — Anker-Insight:** [[Insight-02-Prozesstransparenz-Systemabhaengig]]

**Weitere unterstützende Themes/Pain Points:**
- [[Theme-Prozesstransparenz-Projektuebersicht]]
- [[Theme-Tool-Fragmentierung]]
- [[PP-11-Projektstatus-Tracking-Fehlt]]
- [[PP-12-CS-PSE-Kein-Timeline-Aenderungsrecht]]
- [[Need-08-Responsibility-Visibility-Ball-Bei-Wem]]
- [[Need-07-Selektives-Projektstatus-Tracking]]

**Erwarteter Effekt:** Eliminierung der improvisierten Excel-Workarounds; Reduktion von manuellem Nachfragen und Follow-up-E-Mails; klarere Rolle-zu-Aufgabe-Zuordnung für alle beteiligten Personen; weniger verpasste Fristen durch proaktive Benachrichtigungen.

**Risiko:** Die "Ball-Übergabe"-Logik erfordert klare Prozessdefinitionen: Wann genau wechselt der Verantwortliche? Diese Definitionen müssen prozessual festgelegt sein, bevor sie ins Tool kodiert werden können. Wenn der Prozess selbst nicht klar ist, hilft auch das beste Tool nicht.

## Referenz
Jede Recommendation braucht genau EIN Anker-Insight — siehe [[SOP-Analyseprozess]] Schritt 9.
