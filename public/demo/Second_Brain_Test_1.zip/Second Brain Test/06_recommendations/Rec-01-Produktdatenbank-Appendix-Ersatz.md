---
typ: recommendation
name: "Versionierte Produktdatenbank als Appendix-ABC-Ersatz mit Validierungslogik"
priority: Hoch
erstellt: "2026-07-08"
---

# Recommendation: Versionierte Produktdatenbank als Appendix-ABC-Ersatz mit Validierungslogik

**Empfehlung:** Den Appendix ABC nicht 1:1 digitalisieren, sondern durch eine strukturierte Produktdatenbank je Kunde ersetzen. Diese Datenbank soll: (1) Produktdaten, Codes, BUDIs und Supplier in relationaler Struktur ohne Redundanz abbilden, (2) beim Kundeneintrag kontextbezogene Code-Guidance und Plausibilitätsprüfung aus der Produktbeschreibung liefern, (3) für alle relevanten TÜV-Rollen versioniert und sofort zugänglich sein.

**Evidenz — Anker-Insight:** [[Insight-01-Appendix-ABC-Systemische-Reibung]]

**Weitere unterstützende Themes/Pain Points:**
- [[Theme-Appendix-ABC-Datenqualitaet]]
- [[PP-02-Appendix-Codefehler]]
- [[PP-03-Appendix-Versionszugang]]
- [[PP-04-Appendix-Supplier-Redundanz]]
- [[Need-02-Zentraler-Produktdatenzugang]]

**Erwarteter Effekt:** Weniger Rückfragen durch Fehler im Appendix ABC; kein Zeitverlust durch Suche nach aktuellster Version; Reduktion von Supplier-Inkonsistenzen; Beschleunigung von Application Management und Assessment-Start.

**Risiko:** Kundenseitige Akzeptanz und Lernaufwand für neue Eingabestruktur; regulatorische Anforderungen an Vollständigkeit der Produktdaten müssen in der neuen Struktur weiterhin erfüllbar sein. Automatische Plausibilitätsprüfung aus Produktbeschreibung ist ein Hilfsmittel, kein Ersatz für Expertenurteil.

## Referenz
Jede Recommendation braucht genau EIN Anker-Insight — siehe [[SOP-Analyseprozess]] Schritt 9.
