---
typ: recommendation
name: "Änderungsprotokoll mit optionaler, kontrollierter Kundenbenachrichtigung"
priority: Hoch
erstellt: "2026-07-08"
---

# Recommendation: Änderungsprotokoll mit optionaler, kontrollierter Kundenbenachrichtigung

**Empfehlung:** Jede Änderung an Produktdaten (Codes, BUDIs, Supplier, Klassifizierungen) soll automatisch in einem unveränderlichen Log erfasst werden: Zeitstempel, ausführende Person, betroffenes Feld, Vorher/Nachher-Wert, optionale Begründung. Zusätzlich soll ein Benachrichtigungs-Toggle pro Änderung ermöglichen, den Kunden gezielt zu informieren ("Möchte ich, dass der Kunde das sieht?"). Für formale Klärungsanfragen (z. B. strittige Code-Zuweisung) soll eine strukturierte "Specification Request"-Funktion existieren, die eine dokumentierte Antwort des Kunden anfordert.

**Evidenz — Anker-Insight:** [[Insight-03-Fehlende-Aenderungstransparenz]]

**Weitere unterstützende Themes/Pain Points:**
- [[Theme-Fehlende-Aenderungstransparenz]]
- [[Theme-Appendix-ABC-Datenqualitaet]]
- [[PP-09-Fehlende-Aenderungstransparenz]]
- [[PP-02-Appendix-Codefehler]]
- [[Need-06-Aenderungstransparenz-Bidirektional]]

**Erwarteter Effekt:** Lerneffekt auf Kundenseite durch sichtbare Korrekturen; reduzierende Fehlerwiederholung; regulatorische Absicherung durch vollständigen Audit Trail; klarere Verantwortungstrennung (TÜV legt finale Codes fest, aber transparent und dokumentiert).

**Risiko:** Regulatorische Frage: Was darf "on behalf of the customer" geändert werden, ohne formale Zustimmung? Das ist eine Compliance-Frage, die vor Implementierung mit dem Legal/Regulatory Team zu klären ist. Zu viele Benachrichtigungen könnten Kunden überfordern — daher muss die Toggle-Logik gut durchdacht sein.

## Referenz
Jede Recommendation braucht genau EIN Anker-Insight — siehe [[SOP-Analyseprozess]] Schritt 9.
