---
typ: recommendation
name: "Kontextuelle Prozessführung im Tool je Projekttyp und Phase"
priority: Hoch
erstellt: "2026-07-08"
---

# Recommendation: Kontextuelle Prozessführung im Tool je Projekttyp und Phase

**Empfehlung:** MACE Application soll für jeden Projekttyp (TD, Renewal, Change Notification, Special Project, Orphan Device usw.) automatisch die aktuell gültigen Working Instructions, benötigten Reports und Prozessschritte anzeigen — kontextgebunden zum jeweiligen Projekt, nicht als externe Dokumentensuche. Gleichzeitig soll Projektübersicht (Status, offene To-Dos, Phasen) systemisch sichergestellt sein und nicht von individueller PSE-2.0-Pflege abhängen.

**Evidenz — Anker-Insight:** [[Insight-02-Prozesstransparenz-Systemabhaengig]]

**Weitere unterstützende Themes/Pain Points:**
- [[Theme-Prozesstransparenz-Projektuebersicht]]
- [[PP-07-Working-Instructions-Nachschlagen]]
- [[PP-06-PSE20-Datenqualitaet-International]]
- [[Need-03-Prozesskontextuelle-Guidance]]
- [[Need-05-Systemische-Datenkonsistenz]]

**Erwarteter Effekt:** Weniger Zeitaufwand durch manuelles Nachschlagen von Working Instructions; Fehlerreduktion durch veraltete oder falsche Prozessversion; Projektübersicht auch für internationale Projekte und bei wechselndem Personal gewährleistet.

**Risiko:** Pflege der prozessbezogenen Metadaten im Tool (welche WI gilt für welchen Projekttyp in welcher Prozessversion?) erfordert strukturierte Governance. Wenn das Tool selbst nicht aktuell gehalten wird, verschiebt sich das Problem nur. Außerdem: Klare Abgrenzung zu PSE 2.0 notwendig, um Tool-Duplizierung zu vermeiden (Markus' explizite Warnung).

## Referenz
Jede Recommendation braucht genau EIN Anker-Insight — siehe [[SOP-Analyseprozess]] Schritt 9.
