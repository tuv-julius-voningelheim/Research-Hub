---
typ: theme
name: "Informationsarchitektur folgt nicht dem realen Arbeitsfluss (Macro → Micro)"
confidence: Niedrig
interview_count: 1
quote_count: 4
segmente: Dual-autorisierter Bewerter/Auditor
erstellt: "2026-07-08"
status: vorläufig
---

# Theme: Informationsarchitektur folgt nicht dem realen Arbeitsfluss (Macro → Micro)

## Definition
Der reale Planungsprozess für TÜV-Mitarbeitende verläuft von Makro nach Mikro: Zuerst Technologie-Codes und Fertigungsanwendbarkeiten (→ Audit-Pfad), dann Basic UDIs und Klassifizierungen (→ TD-Pfad), dann erst die Produktfamilien und Varianten (nur relevant für den TD-Bewerter). Die aktuelle Darstellung in MACE Application dreht diese Reihenfolge um: Produktfamilien und Varianten stehen vorne. Das zwingt Mitarbeitende, gegen ihren natürlichen Arbeitsfluss zu navigieren.

⚠️ **Methodischer Hinweis:** Dieses Theme entstand aus einer Prototyp-Evaluations-Sitzung (kein reiner Discovery-Kontext). Befund ist gültig, aber im Kontext einer spezifischen UI-Ansicht geäußert. Allgemeinere Gültigkeit für die Prozessstruktur (nicht nur die UI) ist plausibel, sollte aber in weiteren Interviews bestätigt werden.

## Zugehörige Codes
- #code/informationsarchitektur-umgekehrt
- #code/ui-audit-vs-product-trennung
- #code/characteristics-codes-dopplung
- #code/characteristics-nur-dekoration
- #code/codes-alle-produkte-ganzheitliche-ansicht
- #code/varianten-für-audit-irrelevant
- #code/mdt-codes-fehlen-im-screen

## Repräsentative Zitate
> „In der Ansicht, die ich sehe, ist es ein bisschen umgedreht, wie der Arbeitsprozess läuft und zwar erstmal makroskopisch rauf zu gucken, bis man ins Mikroskopische geht. Was für Technologien habe ich, was für einen Produkttypen habe ich und dann kommt irgendwann, welches Produkt ist es eigentlich?" — INT-002

> „Es doppelt sich ja zwischen Characteristics of Product Family und den Codes. Die Charakteristiken sind die Codes." — INT-002

> „Grundsätzlich würde ich glaube ich die UI so ändern, dass ich dann oben Audit sehe und unten Product Details." — INT-002

> „diese M.D.A. M.D.N. Codes müssen alle Produkte und alle Spezifikationen abdecken. Noch schöner wäre es zu sehen, aus welchem Produkt die Änderung kommt." — INT-002

## Widersprechende Evidenz
Die Ansicht der Produktfamilie kann für den TD-Pfad (Application Review für spezifische Produkte) durchaus sinnvoll sein. Das Argument von INT-002 gilt primär für die Audit-Planung — für andere Rollen (Customer Specialist, TD-Bewerter im Detail) kann die Produktfamilien-Ansicht durchaus relevant sein. Es könnte sich um ein rollenabhängiges Problem handeln, nicht um einen universellen Architekturdefekt.

## Offene Fragen
- Bestätigen Customer Specialists und TD-Bewerter die umgekehrte Logik auch aus ihrer Rollenperspektive?
- Könnte eine rollenbasierte Standardansicht (Auditor vs. TD-Bewerter) dieses Problem lösen?
- Wie häufig muss man zwischen Audit-Pfad und TD-Pfad in derselben Sitzung wechseln?

## Verknüpfte Pain Points
- [[PP-10-Informationsarchitektur-Workflow-Mismatch]]

## Verknüpfte Insights
- (noch kein Insight aufgrund dünner Evidenz — als Research Gap einordnen bis weitere Interviews vorliegen)

## Referenz
Siehe [[Definitionen]] für Confidence-Kriterien, [[SOP-Analyseprozess]] für den Gesamtprozess.
