---
typ: theme
name: "Prozesstransparenz und Projektübersicht systemisch unsicher"
confidence: Hoch
interview_count: 3
quote_count: 12
segmente: TD-Bewerter, Dual-autorisierter Bewerter/Auditor, Customer Specialist+Auditor
erstellt: "2026-07-08"
status: bestätigt
---

# Theme: Prozesstransparenz und Projektübersicht systemisch unsicher

## Definition
Die Projektübersicht (welche Phase, welcher Status, welche offenen To-Dos) hängt vollständig von der disziplinierten Pflege des PSE 2.0-Systems durch einzelne Mitarbeitende ab. Gleichzeitig ändern sich Prozesse, Working Instructions und Projekttypen häufig, ohne dass das System den Bewerter kontextbezogen informiert — er muss selbst nachschlagen. Beides ist strukturell unsicher und produziert blinde Flecken, besonders bei internationalen Projekten.

## Zugehörige Codes
- #code/pse20-gut-gepflegt-vollübersicht
- #code/pse20-internationale-nutzung-keine-übersicht
- #code/working-instructions-manuell-nachschlagen
- #code/viele-projekttypen-prozessvarianten
- #code/prozessführung-im-tool-gewünscht
- #code/pse20-performance-probleme
- #code/projektstatus-tracking-dhl-wunsch (INT-002)
- #code/status-tracking-primär-intern-dann-extern (INT-002)
- #code/eskalationsknopf-mit-entscheidungsmessung (INT-002)
- #code/selektive-statusbenachrichtigungen (INT-002)
- #code/kommunikations-audit-trail (INT-002)
- #code/excel-tracking-eigenbau-weil-kein-tool (INT-003)
- #code/ball-bei-wem-responsibility-visibility (INT-003)
- #code/automatische-benachrichtigung-bei-handlungsbedarf (INT-003)
- #code/manuelles-nachverfolgen-alle-zwei-wochen (INT-003)
- #code/offene-arbeitspakete-sichtbarkeit-gewünscht (INT-003)
- #code/cs-fehlende-pse-editierrechte (INT-003)
- #code/pc-timeline-nicht-eigenständig-angepasst (INT-003)

## Repräsentative Zitate
> „wenn die Datenqualität gut ist, wie es im PSE 20 eingetragen ist, dann sehe ich da eigentlich alles" — INT-001

> „die legen die Tasks nur an, quasi um damit man sie auch buchen können... nicht um irgendeine Ablaufplanung oder Übersicht zu ermöglichen, ne. Und wenn das so gehandhabt wird, dann habe ich eigentlich keinerlei Übersicht mehr." — INT-001

> „ich muss immer wieder die Working Instructions der aktuellen Version auch daneben legen, um die korrekt durchzuführen... Es kostet schon immer wieder Zeit, also ich muss mich immer wieder ein bisschen einlesen, hat sich etwas getan, gibt es Neuerungen" — INT-001

> „wenn in einem Tool dann die immer angezeigt werden würde für dieses Projekt... welche Prozesse, welche Procedures quasi, welche Working Instructions, welche Reports brauche ich jetzt genau für dieses Projekt. Ich denke, das kann sehr, sehr hilfreich sein, ja." — INT-001

## Repräsentative Zitate (INT-002)
> „Tracking von Projektstatus ist mit Sicherheit eine wichtige Sache. wenn man das hier einbauen könnte wie bei einem DHL Paket, in welchem Status wir uns befinden, wo das Paket sich gerade befindet." — INT-002

> „Für mich noch viel besser als für den Kunden ehrlich gesagt. Und das freizugeben für den Kunden on demand." — INT-002

> „Ein Eskalationsknopf wäre natürlich super toll... einen Prio-Knopf... für Auseinandersetzungen oder auch von Entscheidungsfindung mit einer Messbarkeit, von Anfrage bis zur Entscheidung, das wäre phänomenal." — INT-002

> „auch ein Kommunikationsfinder wäre sehr cool, um zu tracken, welche Informationen geteilt wurden." — INT-002

## Repräsentative Zitate (INT-003)
> „das wäre cool, dass man so das so sehen könnte, okay bei wem liegt gerade der Ball in dem Sinne und muss ich überhaupt irgendwas machen, muss ich aktiv werden." — INT-003

> „da kriege ich im Endeffekt selber eine Liste, die ist nicht schön, aber im Endeffekt einfach nur, wo ich auch wirklich so Kleinigkeiten einfach reinschreibe... damit ich nicht in Tagen wieder denke, was ist denn da der letzte Stand." — INT-003

> „wenn ich die Rechte hätte, in der Zeit, wo ich ihr dann noch mal die E-Mail schreibe, dass ihr die Timeline anfasst... könnt ich es einfach direkt selber updaten." — INT-003

> „dass dieses Nachverfolgen vielleicht auch gar nicht mehr nötig ist, weil der andere dann ja auch sieht, bei ihm liegt der Ball und dann vielleicht von alleine irgendwie eine Mail kriegt." — INT-003

## Widersprechende Evidenz
Für lokale Projekte in Deutschland funktioniert PSE 2.0 nach Markus gut — das Problem ist regional konzentriert (internationale Projekte) und prozessabhängig (häufige Änderungen). Kein generelles PSE-Versagen.
INT-002 kommentiert PSE 2.0 nicht direkt, adressiert aber denselben Kern: fehlende Sichtbarkeit von Status und Prozessfortschritt im Arbeitsalltag.

## Offene Fragen
- Wie verbreitet ist die „nur buchen"-Nutzung von PSE 2.0 bei internationalen Teams?
- Gibt es eine zentrale Dokumentationsplattform für Working Instructions, die das Tool anbinden könnte?
- Decken andere Rollen (Customer Specialist, Project Coordinator) dasselbe Problem?

## Verknüpfte Pain Points
- [[PP-06-PSE20-Datenqualitaet-International]]
- [[PP-07-Working-Instructions-Nachschlagen]]
- [[PP-11-Projektstatus-Tracking-Fehlt]]
- [[PP-12-CS-PSE-Kein-Timeline-Aenderungsrecht]]

## Verknüpfte Insights
- [[Insight-02-Prozesstransparenz-Systemabhängig]]

## Referenz
Siehe [[Definitionen]] für Confidence-Kriterien, [[SOP-Analyseprozess]] für den Gesamtprozess.
