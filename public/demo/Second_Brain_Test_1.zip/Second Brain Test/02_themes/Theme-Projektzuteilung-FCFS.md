---
typ: theme
name: "Intransparente und ungerechte Projektzuteilung (FCFS)"
confidence: Niedrig
interview_count: 1
quote_count: 3
segmente: TD-Bewerter
erstellt: "2026-07-08"
status: vorläufig
---

# Theme: Intransparente und ungerechte Projektzuteilung (FCFS)

## Definition
Das Scheduling Team verteilt Projekte nach dem First-Come-First-Serve-Prinzip: Wer als Erstes auf die Anfrage klickt, bekommt das Projekt. Dies führt zu struktureller Arbeitslastungleichverteilung und bevorzugt Mitarbeitende, die in dem Moment gerade verfügbar sind — unabhängig von tatsächlicher Kapazität oder Expertise.

## Zugehörige Codes
- #code/projektzuteilung-FCFS-problem
- #code/arbeitslast-ungleichverteilung
- #code/zuteilung-zeitfenster-idee
- #code/projektzuteilung-email-medici

## Repräsentative Zitate
> „Das geht auch auf Zeit quasi. Also der als erstes First Come First Serve Prinzip quasi, das ist schon mal ein erster Punkt der schwierig ist ja. Weil meistens komme ich erst wenn ich am Projekt sitz sag ich mal am Ende des Tages dazu da reinzuschauen am nächsten Tag und dann merkt man eigentlich dass also wenn man nicht in den ersten ein, zwei, drei oder fünf Minuten klickt ist es eigentlich schon weg." — INT-001

> „Ich denke das könnte auch schon mal ein Punkt sein der zu einer Ungleichverteilung von der Arbeitslast führt." — INT-001

> „auf jeden Fall besser als First Come for Surfer schon mal 'n Zeitfenster, wir haben meinten meine erste Idee, sag ich mal 24 Stunden. und dann sieht man, wer klickt und dann muss man entscheiden... wer da wirklich am wenigsten Auslastung von den Leuten, die dann zugesagt haben" — INT-001

## Widersprechende Evidenz
Markus erwähnt, dass das Scheduling Team bereits Kapazitäten und Autorisierungen prüft — das FCFS-Problem betrifft die finale Auswahl unter den qualifizierten Personen, nicht die grundsätzliche Vorauswahl. Relationship Manager können außerdem gezielt Bewerter anfragen. Das System ist also nicht vollständig ungesteuert.

## Offene Fragen
- Wie häufig führt FCFS tatsächlich zu messbaren Ungleichgewichten (Daten aus PSE 2.0 prüfbar)?
- Wie verbreitet ist dieses Empfinden unter anderen TD-Bewertern?
- Gibt es bereits Bestrebungen im Scheduling Team, das zu ändern?

## Verknüpfte Pain Points
- [[PP-01-FCFS-Projektzuteilung]]

## Verknüpfte Insights
- (noch kein Insight — zu wenig Evidenz)

## Referenz
Siehe [[Definitionen]] für Confidence-Kriterien, [[SOP-Analyseprozess]] für den Gesamtprozess.
