---
typ: theme
name: "Timeline-Unzuverlässigkeit (intern & aus Kundensicht)"
confidence: Niedrig
interview_count: 1
quote_count: 3
segmente: TD-Bewerter
erstellt: "2026-07-08"
status: vorläufig
---

# Theme: Timeline-Unzuverlässigkeit (intern & aus Kundensicht)

## Definition
Die tatsächlichen Projektlaufzeiten weichen systematisch von den definierten Servicemodell-Timelines ab (Application-to-Certification KPI). Besonders in der letzten Phase vor der Zertifizierung (STC/LTR Review) entstehen Verzögerungen, die für Kunden nicht transparent sind. Fehlende Traceability macht es schwer, die Ursache von Verzögerungen zu lokalisieren.

## Zugehörige Codes
- #code/timeline-unsicherheit-zertifizierungsphase
- #code/planungsdauer-vs-realität-diskrepanz
- #code/pse20-deadlines-priorisierung

## Repräsentative Zitate
> „ich denke, der größte Pain Point für Kunden ist, wenn wenn die Timeline nicht eingehalten werden, weil der Kunde, der muss zuverlässig wissen, wann wann ist jetzt eine Bewertung fertig... dieser letzte Schritt quasi vor der Zertifizierung, wenn es dann im Review ist durch STC... Da war zwar auch eine Timeline in unseren Servicemodellen, aber da da kommt es oft zu Rückfragen quasi, dann verschiebt sich oder verlängert sich der Slot." — INT-001

> „vergleicht man das mit der tatsächlichen Zeit, wie lange es dauert. A. to C. nennen wir diesen diesen Key K. K. I. also von der Application bis zur Certification... sieht man sicher die Diskrepanz, dass es in der Realität deutlich länger dauert." — INT-001

## Widersprechende Evidenz
Markus weist darauf hin, dass Verzögerungen oft auf Kundenseite liegen (fehlende Daten, ausstehende Studien) — TÜV ist nicht allein verantwortlich. Der KPI-Vergleich ist ein gemischtes Signal.

## Offene Fragen
- Wo liegen Verzögerungen prozentual? (TÜV-intern vs. Kundenseite vs. STC-Phase)
- Empfinden Kunden dasselbe Problem? (Kundenperspektive noch nicht direkt erhoben)
- Welche KPI-Daten existieren bereits (A-to-C Laufzeiten)?

## Verknüpfte Pain Points
- [[PP-08-Timeline-Zertifizierungsphase-Kunden]]

## Verknüpfte Insights
- (kein eigenständiger Insight bei dieser Evidenzlage — als Research Gap einordnen)

## Referenz
Siehe [[Definitionen]] für Confidence-Kriterien, [[SOP-Analyseprozess]] für den Gesamtprozess.
