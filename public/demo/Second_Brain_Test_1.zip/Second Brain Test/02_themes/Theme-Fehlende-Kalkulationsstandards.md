---
typ: theme
name: "Fehlende Kalkulationsstandards und unklare Gebührenregelung"
confidence: Niedrig
interview_count: 1
quote_count: 3
segmente: Customer Specialist+Auditor
erstellt: "2026-07-08"
status: vorläufig
---

# Theme: Fehlende Kalkulationsstandards und unklare Gebührenregelung

## Definition
Für mehrere Leistungsarten (Change Notifications, Supplier Audits, Special Audits) gibt es keine offiziellen, in ROXPA hinterlegten Kalkulationsvorlagen. Mitarbeitende nutzen informelle Wiki-Vorlagen oder schätzen selbst. Gleichzeitig ist unklar, wann welche Fees (z. B. Notified Body Review Fee, Certification Review Fee) zu berechnen sind — weder CS, PC noch RM können dies verlässlich beantworten. Das führt zu inkonsistenten Kalkulationen und Entscheidungen "nach Bauchgefühl".

## Zugehörige Codes
- #code/kalkulation-fehlende-offizielle-vorlage
- #code/fee-regelung-unklar-niemand-weiß

## Repräsentative Zitate
> „Bei mir ist es auch oft so, dass ich irgendwie Supplier Audit kalkuliere, da kann ich mir wieder anscheinend alles aus dem Daumen schütteln... Change Notifications, da gibt es nicht so eine richtig offizielle Vorlage... nichts, was in ROXPA ist und so ein bisschen inoffiziell läuft." — INT-003

> „anscheinend nie ganz klar, jetzt mit diesen Gebühren. Also brauche ich eine Multiplied Body Review Fee, brauche ich eine Certification Review Fee... das wissen beide einfach selber nicht und dann entscheiden sie einfach irgendwas." — INT-003

> „Ich habe da mal, also es gibt da glaube ich auch in Wiki irgendwie so eine Seite, wo manche Leute sich von irgendeinem Template bedienen, aber das ist nichts, was in ROXPA ist und so ein bisschen inoffiziell läuft." — INT-003

## Widersprechende Evidenz
Für TD Assessment und Audit gibt es standardisierte Berechnungsgrundlagen (PPS, Effort Calculation). Das Problem trifft nur bestimmte Leistungsarten — es ist keine vollständige Lücke, sondern punktuell. Kunden beschweren sich laut INT-003 (noch) nicht über die Fees selbst.

## Offene Fragen
- Sind die Regeln tatsächlich undokumentiert oder nur schwer auffindbar?
- Betrifft das andere Rollen genauso (andere Customer Specialists, PCs, RMs)?
- Hat die unklare Fee-Berechnung bisher zu Abrechnungsfehlern oder Kundenreklamationen geführt?
- Research Gap: Nur 1 Interview (INT-003) — weiterer Beleg nötig.

## Verknüpfte Pain Points
- [[PP-13-Fehlende-Offizielle-Kalkulationsvorlage]]
- [[PP-14-Fee-Regelung-Unklar]]

## Verknüpfte Insights
- (kein Insight bei dieser Evidenzlage — als Research Gap einordnen)

## Referenz
Siehe [[Definitionen]] für Confidence-Kriterien, [[SOP-Analyseprozess]] für den Gesamtprozess.
