---
typ: theme
name: "Schnittstellenbottlenecks bei internationalen Projekten"
confidence: Niedrig
interview_count: 1
quote_count: 4
segmente: TD-Bewerter
erstellt: "2026-07-08"
status: vorläufig
---

# Theme: Schnittstellenbottlenecks bei internationalen Projekten

## Definition
Internationale Projekte involvieren viele Parteien (Bewerter, lokaler Project Handler, BSC/Global BSC, Subcontractor), deren Schnittstellen schlecht ineinandergreifen. Kommunikation ist langsam, Zuständigkeiten unklar, und administrative Pflichtschritte (z. B. Subcontract-Erstellung) können Monate dauern und die eigentliche Arbeit vollständig blockieren.

## Zugehörige Codes
- #code/subcontract-verzögerung-blockierend
- #code/internationale-kommunikation-langsam-indien
- #code/pse20-internationale-nutzung-keine-übersicht
- #code/kommunikation-fehlende-projektzuordnung

## Repräsentative Zitate
> „ich hatte ein Projekt, da haben wir wiederholt immer wieder nachgefragt und wir haben kein Subcontract bekommen. Ohne den können wir eigentlich, wenn wir nicht keinen Auftrag haben, können nicht buchen können, können wir auch nicht arbeiten, eigentlich. Es gibt die Regulatoria vor, ich denk, da hat 3 Monate gebraucht, bis dann Subcontract da war, was eigentlich noch keine Ahnung an dem halben Tag gehen gehen sollte oder könnte." — INT-001

> „wenn es Richtung Indien geht, habe ich jetzt persönlich eher schlecht... Erfahrungen gemacht, warte mal so lang auf die Antwort und dann geht es wieder erst zum Manager. Der Manager muss dann wieder dem Project Lander sagen, er muss das machen. Also da geht es sehr oft hin und her und dann wartet man halt wirklich Wochen und Monate" — INT-001

## Widersprechende Evidenz
Markus beschreibt Thailand als positives Gegenbeispiel: „Da sind die Project Lander sehr auf zack und antworten sehr schnell." — Das Problem ist nicht generell international, sondern regional unterschiedlich und hängt von lokalen Prozessdisziplinen ab.

## Offene Fragen
- Sind die Subcontract-Verzögerungen systematisch dokumentiert?
- Welche strukturellen Unterschiede erklären die regionalen Qualitätsunterschiede?
- Wie wirkt sich das auf die Gesamtprojektlaufzeit (Application-to-Certification KPI) aus?

## Verknüpfte Pain Points
- [[PP-05-Subcontract-Verzoegerung-International]]

## Verknüpfte Insights
- [[Insight-02-Prozesstransparenz-Systemabhängig]]

## Referenz
Siehe [[Definitionen]] für Confidence-Kriterien, [[SOP-Analyseprozess]] für den Gesamtprozess.
