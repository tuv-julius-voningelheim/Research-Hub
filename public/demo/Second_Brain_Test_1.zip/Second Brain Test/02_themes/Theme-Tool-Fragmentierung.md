---
typ: theme
name: "Tool-Fragmentierung und fehlende Projektzuordnung in Kommunikation"
confidence: Mittel
interview_count: 2
quote_count: 6
segmente: TD-Bewerter, Customer Specialist+Auditor
erstellt: "2026-07-08"
status: vorläufig
---

# Theme: Tool-Fragmentierung und fehlende Projektzuordnung in Kommunikation

## Definition
Der Arbeitsalltag des TD-Bewerters verteilt sich auf mehrere nicht integrierte Tools (PSE 2.0, APC/Appendix ABC, Medici, MS Teams, Outlook). Kommunikation findet dezentral statt (Teams, E-Mail, ggf. Telefon) ohne direkte Verknüpfung zu Projektobjekten. Das erzeugt manuelle Aufwände (Projektnummer in jeder Nachricht eintragen) und Risiko, dass Informationen nicht auffindbar sind.

## Zugehörige Codes
- #code/kommunikation-fehlende-projektzuordnung
- #code/tool-duplizierung-risiko
- #code/pse20-performance-probleme
- #code/idas-ki-bewertung-positiv
- #code/plattformlösung-end-to-end-vision
- #code/zwei-kanäle-uci-email-hindernis (INT-003)
- #code/uci-projektkommunikation-traceability (INT-003)
- #code/excel-tracking-eigenbau-weil-kein-tool (INT-003)

## Repräsentative Zitate (INT-003)
> „diese zwei Kanäle sind auch manchmal eher ein Hindernis, dass man das irgendwie nachverfolgen kann." — INT-003

> „das versuche ich jetzt eher dann alles per U.C.I. zu machen... pro Projekt halt die Kommunikation einfach da nachvollziehen kann, ich erst irgendwie 1000 Mails nach." — INT-003

## Repräsentative Zitate
> „muss man sich immer die Projektnummer, irgendeine Referenz SAP Nummer oder oder PSE Projektnummer reinschreiben, dass ich 'ne Referenz irgendeinen Anhaltspunkt habe, welches Projekt geht es quasi." — INT-001

> „muss man aufpassen, dass nicht zwei Tools hat PSE 2.0 und ein weiteres Tool, dass dann beide versuchen das gleiche zu machen" — INT-001

> „'n Plattformgedanke, quasi 'ne Plattformlösung, wo dann wirklich von Anfang von Application bis zum Ende des Zertifikats und auch danach dann noch vielleicht Post Certification, vielleicht der Status überwacht wird" — INT-001

## Widersprechende Evidenz
Markus beschreibt die lokale interne Kommunikation (Deutschland, Teams/E-Mail) als funktionierend — das Problem ist nicht allgegenwärtig, sondern tritt besonders bei komplexen, internationalen oder phasenübergreifenden Situationen zutage.

## Offene Fragen
- Welche Tools werden von anderen Rollen (Customer Specialist, Relationship Manager) als zentral angesehen?
- Gibt es bereits eine Integrationsroadmap zwischen PSE 2.0 und MACE Application?
- Wie oft geht Kommunikation tatsächlich verloren oder ist nicht auffindbar?

## Verknüpfte Pain Points
- [[PP-05-Subcontract-Verzoegerung-International]]
- [[PP-03-Appendix-Versionszugang]]

## Verknüpfte Insights
- [[Insight-02-Prozesstransparenz-Systemabhängig]]

## Referenz
Siehe [[Definitionen]] für Confidence-Kriterien, [[SOP-Analyseprozess]] für den Gesamtprozess.
