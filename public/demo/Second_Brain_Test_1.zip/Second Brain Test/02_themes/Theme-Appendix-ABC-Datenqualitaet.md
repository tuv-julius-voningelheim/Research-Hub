---
typ: theme
name: "Appendix ABC als fragile, fehlerhafte Datengrundlage"
confidence: Hoch
interview_count: 3
quote_count: 16
segmente: TD-Bewerter, Dual-autorisierter Bewerter/Auditor, Customer Specialist+Auditor
erstellt: "2026-07-08"
status: bestätigt
---

# Theme: Appendix ABC als fragile, fehlerhafte Datengrundlage

## Definition
Der Appendix ABC ist die zentrale Datenquelle für Produktinformationen, Codes und Autorisierungsanforderungen — aber er ist fehleranfällig (Kundeneingaben), strukturell redundant (Supplier-Daten in mehreren Sheets), in keiner zentralen, immer aktuellen Version verfügbar und macht keine automatische Validierung. Das führt zu systematischen Reibungen bei TÜV-Mitarbeitenden.

## Zugehörige Codes
- #code/appendix-abc-hauptdatenquelle
- #code/appendix-abc-komplexität-fehlerquellen
- #code/codes-autorisierung-verknüpfung
- #code/code-selbstkorrektur-möglich
- #code/appendix-supplier-redundanz-inkonsistenz
- #code/appendix-version-zugang-umständlich
- #code/appendix-zu-datenbank-ansatz-richtig
- #code/kundenguidance-codes-und-validierung
- #code/produktbeschreibung-code-ableitung
- #code/code-ableitung-automatisierung-potenzial
- #code/appendix-abc-blackbox-für-kunden (INT-002)
- #code/customer-specialist-codes-best-guess (INT-002)
- #code/appendix-abc-häufigste-fehlerquelle-ssot (INT-002)
- #code/ki-code-vorschlag-wertvoll (INT-002)
- #code/eudamed-als-validierungsquelle (INT-002)
- #code/appendix-abc-fehlt-oder-unvollständig-bei-einreichung (INT-003)
- #code/appendix-abc-zeitpunkt-unklar-change-kunden (INT-003)
- #code/appendix-abc-cleanup-zeitfresser-cs (INT-003)
- #code/appendix-abc-validierung-elektronisch-lösbar (INT-003)
- #code/appendix-abc-datenbank-mit-validierung-gewünscht (INT-003)
- #code/appendix-abc-schwierig-kundenfeedback-direkt (INT-003)
- #code/sap-schnittstelle-appendix-upload-kundenwunsch (INT-003)

## Repräsentative Zitate
> „das Nächste ist dann für mich wirklich das Wichtigste, dieser Appendix ABC quasi, der mir genau sagt, welche Produkte sind betroffen, welche Codes haben die Produkte, dass ich die nötigen Autorisierungen für die Module rausfinden kann." — INT-001

> „Das ist ein komplexes Dokument natürlich der Appendix A. B. C. auch verschiedenste Produkte aufgeführt werden... es kommen immer noch zu Rückfragen, auf jeden Fall. Manchmal ist auch nicht so ganz klar, ist der Code jetzt relevant für das Produkt oder nicht... da geht das bisschen hin und her und das kann viel Zeit kosten." — INT-001

> „gibt so ein paar Redundanzen, also im Sheet 1 zum Beispiel... Die gleiche Information oder ähnlich habe ich aber dann noch mal in diesen Sheets dahinter, A. Punkt 2 oder A. Punkt 3 zum Beispiel für Sterilization... und die sind oft widersprüchlich" — INT-001

> „wenn der Appendix ABC in der aktuellen Version für alle zugänglich wäre oder aufrufbar wäre... ich frag auch immer den Customer Specialist oder Relationship Manager, weil der weiß meistens, wo ist was ist der aktuellste, die aktuellste Version von Appendix A. B. C. Das kostet ein bisschen... wenn der gerade im Urlaub ist oder was, kann natürlich auch ein bisschen Zeit kosten" — INT-001

## Repräsentative Zitate (INT-003)
> „gerade im Appendix ABC, da verliere ich glaube ich am meisten Zeit. Gerade wenn da viele Artikel drauf sind... eigentlich ist jede Application, die mir mein Großkunde schickt, dauert extrem lange, weil in dieser Bearbeitung von der Application, im Endeffekt ich die Daten aufräume." — INT-003

> „es fällt mir während des Assessments so wann Sachen auf wie, es gibt hier in einer Basic UDI verschiedene intended users. Dürfen sie eigentlich gar nicht haben. Solche Sachen könnte man ja auch elektronisch im Idealfall irgendwie schon vorab irgendwie klären." — INT-003

> „der Augenblick so ganz bewusst ist, wann ändere ich diesen Appendix ABC? Erst wenn der Change quasi von uns akzeptiert ist oder schon am Anfang, das sind so typische Sachen, die ich immer wieder erklären muss." — INT-003

> „Appendix A. B. C. Also das krieg ich schon regelmäßig als Rückmeldung, dass das schwierig ist." — INT-003 (Kundenperspektive, direkt berichtet)

> „wäre halt richtig cool, wenn das irgendwie alles nicht in Excel wäre, sondern die Informationen in Daten irgendwie gespeichert wäre, da Cross-Checks automatisch möglich sind. bestimmte Sachen gar nicht einzugeben sind durch den Kunden, weil das nicht geht regulatorisch." — INT-003

## Widersprechende Evidenz
Markus sagt auch: „Ich finde das Dokument eigentlich schon ganz gut, das sagt einem schon sehr, sehr viel aus." — Die Probleme sind struktureller Natur, nicht grundsätzlicher. Das Dokument liefert im Kern die richtigen Daten, nur die Qualitätssicherung fehlt.
INT-002 bestätigt keine direkte Verfügbarkeitsproblematik der Versionen — sein Fokus liegt mehr auf dem Blackbox-Charakter für Kunden und der Fehleranfälligkeit der Codes.

## Repräsentative Zitate (INT-002)
> „Der normale Weg ist 'Hey, das ist mein Produkt' und dann sagen wir 'Füll mal bitte den Appendix ABC aus, die versuchen das nach dem Best Guest zu machen, ohne zu wissen, warum wir was anfragen.'" — INT-002

> „Diese Sichtweise, über die wir so standardmäßig reden, ist für Legalhersteller eigentlich eine riesen Blackbox. Also die verstehen gar nicht, was wollen die mit MDT und was passiert mit MDS." — INT-002

> „Derzeit ist der Appendix A. B. C. die vollendete Wahrheit, die maßgeblich sein muss... Und auch das Dokument, das am häufigsten verändert wird, logischerweise. Weil es am unrichtigsten ist." — INT-002

> „Sehe ich hier als cool, wenn ihr da irgendwie so ein AI-Tool einbaut, Prescription of Codes oder irgendwie Equivalence Products oder so, wäre das natürlich sehr sexy." — INT-002

## Offene Fragen
- Wie häufig entstehen tatsächlich Projektverzögerungen durch Fehler im Appendix ABC (messbar)?
- Welche anderen Rollen (Customer Specialist, Relationship Manager) sehen dieselben Probleme?
- Wäre eine automatische Code-Plausibilitätsprüfung aus Produktbeschreibung technisch umsetzbar und würde sie akzeptiert?

## Verknüpfte Pain Points
- [[PP-02-Appendix-Codefehler]]
- [[PP-03-Appendix-Versionszugang]]
- [[PP-04-Appendix-Supplier-Redundanz]]

## Verknüpfte Insights
- [[Insight-01-Appendix-ABC-Systemische-Reibung]]

## Referenz
Siehe [[Definitionen]] für Confidence-Kriterien, [[SOP-Analyseprozess]] für den Gesamtprozess.
