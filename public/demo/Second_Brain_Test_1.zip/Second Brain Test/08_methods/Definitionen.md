
# Definitionen: Confidence, Severity, Evidenzqualität

Diese Begriffe sind keine Bauchgefühl-Labels. Wende sie konsequent an, damit "Hoch" bei jedem Theme,
Pain Point und Insight im Repository dasselbe bedeutet – sonst werden die Labels zu Rauschen statt zu Signal.

## Confidence (Vertrauenswürdigkeit)

Beschreibt, wie sicher du dir bist, dass ein Theme/Pain Point/Insight ein echtes, wiederkehrendes Muster
widerspiegelt – und kein Einzelfall oder eine Fehlinterpretation.

Basiert auf drei Faktoren zusammen, nicht auf einem einzelnen:

1. **Wiederholung** – wie viele unterschiedliche Interviews/Teilnehmer liefern Evidenz dafür?
2. **Konsistenz** – beschreiben Teilnehmer es gleich, oder gibt es Widersprüche? Widersprechende Evidenz senkt
   Confidence nicht automatisch auf null, muss aber dokumentiert werden (Feld "Contradicting Evidence").
3. **Direktheit** – hat die Person das klar ausgesprochen, oder ist es aus indirekten Signalen abgeleitet
   (Tonfall, Zögern, ein beiläufig erwähnter Workaround)? Direkte Aussagen stützen höhere Confidence als Inferenz.

Drei Stufen:

- **Hoch** – wiederholt sich über mehrere Interviews (i.d.R. 3+, oder Mehrheit einer kleinen Stichprobe),
  konsistent beschrieben, überwiegend direkte Evidenz, kaum/keine glaubwürdigen Widersprüche.
- **Mittel** – wiederholt sich über 2+ Interviews, ODER 1 Interview mit starker/direkter Evidenz,
  etwas Inferenz beteiligt, oder ungelöste widersprechende Evidenz vorhanden.
- **Niedrig** – nur 1 Interview, indirekt/abgeleitet, oder durch andere Evidenz widerlegt. Trotzdem festhalten
  (nicht verwerfen!), aber klar als vorläufig kennzeichnen und Richtung Research Gaps/offene Fragen einordnen –
  nicht als gesichert behandeln.

Die Confidence eines Themes sollte sichtbar steigen, wenn neue Interviews integriert werden und sich das Muster
wiederholt – dieser Verlauf selbst ist nützlich zu zeigen.

## Severity (nur für Pain Points)

Beschreibt, wie teuer der Pain Point für den Nutzer ist, wenn er nicht behoben wird – unabhängig davon,
wie viele Personen ihn berichtet haben.

- **Kritisch** – blockiert die Aufgabe komplett, verursacht Datenverlust/Fehler, oder führt zum Abbruch
  des Produkts/Workflows.
- **Hoch** – erzwingt einen erheblichen Workaround, kostet wiederholt spürbar Zeit/Vertrauen, oder verursacht
  sichtbare Frustration/Anspannung während der Aufgabe.
- **Mittel** – echte Reibung, aber die Person passt sich an ohne große Kosten; nervig, aber nicht blockierend.
- **Niedrig** – kleine Unannehmlichkeit, meist beiläufig erwähnt, kaum Einfluss auf das Ergebnis.

Wichtig: Severity ist NICHT dasselbe wie Confidence. Ein Pain Point kann Severity "Kritisch" bei Confidence
"Niedrig" haben (eine Person beschreibt etwas Gravierendes, aber du hast nur diesen einen Datenpunkt) –
so berichten, nicht beides zu einem unklaren Mittelwert verrechnen. Diese Kombination selbst ist erwähnenswert,
da ein einzelner kritischer Bericht oft gezielte Anschlussforschung verdient, noch bevor hohe Confidence erreicht ist.

## Evidenzqualität – was zählt als stark vs. schwach

**Starke Evidenz:**
- Eine konkrete, zitierbare Aussage mit Bezug zu einer spezifischen Situation
  ("Ich hab's dreimal exportiert, weil ich den ersten zwei Durchläufen nicht traute")
- Evidenz, die durch einen Workaround, eine beschriebene Konsequenz oder eine Nachfrage im Interview gestützt wird
- Evidenz, die unabhängig in mehreren Interviews auftaucht (nicht weil Teilnehmer durch eine Suggestivfrage geprimt wurden)

**Schwache Evidenz:**
- Eine vage, allgemeine Aussage ohne konkrete Situation ("ist irgendwie manchmal nervig")
- Eine einzelne beiläufige Bemerkung ohne Ausführung
- Etwas, das der Researcher aus Tonfall/Subtext ableitet, statt dass es ausgesprochen wurde
- Evidenz, die aus einer Suggestivfrage im Interview-Leitfaden stammt (vermerken, falls aus dem Transkript erkennbar)

Bei schwacher Evidenz: ruhig als Code oder in Research Gaps festhalten – nur nicht direkt zu einem
Theme, Pain Point oder Insight hochstufen. Auf weitere Bestätigung warten, oder explizit als
Prüfpunkt für Folgeforschung kennzeichnen.


# Qualitäts-Checkliste

Vor jedem Abschluss einer Analyse (egal ob erstes Interview oder Update-Runde) diese Liste durchgehen.
Schlägt ein Punkt fehl: entweder beheben, oder – falls mit der vorhandenen Evidenz nicht behebbar –
explizit unter "Research Gaps" der betroffenen Notiz vermerken. Nicht stillschweigend ausliefern.

- [ ] Jedes Theme hat mindestens eine stützende Evidenz (nicht nur Name + Definition)
- [ ] Jedes Theme hat mindestens ein repräsentatives Zitat
- [ ] Jeder Pain Point gehört zu genau einem Theme – keiner unzugeordnet oder doppelt zugeordnet
- [ ] Jeder Pain Point enthält Evidenz (Zitate und/oder Interview-IDs) – nicht nur eine behauptete Beschreibung
- [ ] Jedes Insight verweist auf mindestens ein stützendes Theme
- [ ] Jede Recommendation verweist auf genau ein Anker-Insight
- [ ] Widersprechende Evidenz ist bei Themes gelistet, wo sie existiert – nicht geglättet, um sauberer auszusehen
- [ ] Confidence ist überall gesetzt (Themes, Pain Points, Insights) – nicht leer oder nur impliziert
- [ ] Annahmen/Inferenzen sind sichtbar von direkten Beobachtungen getrennt
- [ ] Unklare Informationen sind explizit markiert, nicht stillschweigend weggelassen
- [ ] Kein Finding ist allein nach Häufigkeit priorisiert (Severity/Priority spiegeln Impact × Evidenzqualität × Wiederholung × Severity zusammen)
- [ ] Keine Sentiment-Scores oder Word-Cloud-Häufigkeitsvisualisierungen als Analyse-Ersatz verwendet
- [ ] Bei Update eines bestehenden Repositories: bestehende Themes wiederverwendet wo Evidenz passte, neue Themes begründet

## Verwandte Dateien
- [[SOP-Analyseprozess]]
- [[Definitionen]]