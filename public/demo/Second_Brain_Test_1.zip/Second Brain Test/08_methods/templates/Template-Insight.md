---
typ: insight
name: "{{title}}"
confidence: 
priority: 
erstellt: "{{date}}"
---

# Insight: {{title}}

**Insight:** [die synthetisierte Aussage, 1-3 Sätze]
**Stützende Themes:** [[]], [[]]

## Evidenz
**Stützende Zitate:**
> "" — [Interview-ID]

**Business Impact:** 
**Design Implication:** 

## Referenz
Wenn die Evidenz dünn ist: KEIN Insight anlegen — stattdessen in [[SOP-Analyseprozess]] Research Gaps.
