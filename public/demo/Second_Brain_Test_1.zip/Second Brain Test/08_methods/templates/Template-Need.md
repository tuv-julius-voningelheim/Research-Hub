---
typ: need
name: "{{title}}"
kategorie: 
theme: 
erstellt: "{{date}}"
---

# Need: {{title}}

**Kategorie:** [Funktional / Emotional / Sozial / Latent]
**Beschreibung:** 
**Zugehöriges Theme:** [[]]

## Evidenz
**Repräsentative Zitate:**

> "" — [Interview-ID]

> Hinweis bei "Latent": explizit als Inferenz kennzeichnen, nicht als direkte Aussage.
