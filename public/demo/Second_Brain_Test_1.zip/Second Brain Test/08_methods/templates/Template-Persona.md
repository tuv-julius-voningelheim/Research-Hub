---
typ: persona
name: "{{title}}"
segment: 
anzahl_interviews: 
erstellt: "{{date}}"
status: proto-persona
---

# Persona: {{title}}

⚠️ **Vor dem Ausfüllen prüfen:** Basiert das auf mindestens 3 unterschiedlichen Interviews mit
konsistentem Muster? Wenn nein → Status auf `proto-persona` lassen und als Hypothese behandeln.
Siehe [[Definitionen]] Confidence-Kriterien — dieselbe Logik gilt hier.

**Segment:** 
**Basiert auf Interviews:** [[]], [[]], [[]]

## Kontext
[Rolle, Workflow, Umfeld]

## Ziele
[Was will diese Person erreichen?]

## Zugehörige Themes
- [[]]

## Zugehörige Pain Points
- [[]]

## Zugehörige Needs
- [[]]