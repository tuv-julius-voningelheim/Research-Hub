---
typ: recommendation
name: "{{title}}"
priority: 
erstellt: "{{date}}"
---

# Recommendation: {{title}}

**Empfehlung:** [die konkrete Handlungsempfehlung]
**Evidenz — Anker-Insight:** [[]]
**Weitere unterstützende Themes/Pain Points:** 
**Erwarteter Effekt:** 
**Risiko:** [was ungetestet ist / welche Annahme das voraussetzt]

## Referenz
Jede Recommendation braucht genau EIN Anker-Insight — siehe [[SOP-Analyseprozess]] Schritt 9.