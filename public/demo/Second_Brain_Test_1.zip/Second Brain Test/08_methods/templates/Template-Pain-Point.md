---
typ: pain-point
name: "{{title}}"
theme: 
severity: 
confidence: 
erstellt: "{{date}}"
---

# Pain Point: {{title}}

**Theme:** [[]]
**Beschreibung:** 
**Trigger:** 
**Impact:** 
**Workaround:** 

## Evidenz
**Evidence Count:** 
**Interview-IDs:** 

**Repräsentative Zitate:**
> "" — [Interview-ID]

## Mögliche Opportunity
[Kurzer, unverbindlicher Hinweis — konkrete Recommendation kommt separat]

## Referenz
Siehe [[Definitionen]] für Severity-Kriterien.