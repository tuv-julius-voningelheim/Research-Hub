---
typ: interview
teilnehmer_id: "{{title}}"
segment: 
datum: "{{date}}"
status: unbearbeitet
---

# Interview: {{title}}

## Kontext (Schritt 1 — vor dem Coden)
- Wer ist die Person / welcher Kontext?
- Welchen Workflow/welche Aufgabe beschreibt sie?
- Was will sie erreichen?
- Welche Emotionen kamen auf?

## Transkript in Meaning Units

> [Original-Zitat]
Code: #code/

> [Original-Zitat]
Code: #code/

## Referenz
Siehe [[SOP-Analyseprozess]] Schritt 1-3.