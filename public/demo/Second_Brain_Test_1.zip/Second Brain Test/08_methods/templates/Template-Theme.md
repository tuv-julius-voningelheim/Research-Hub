---
typ: theme
name: "{{title}}"
confidence: 
interview_count: 
quote_count: 
segmente: 
erstellt: "{{date}}"
status: vorläufig
---

# Theme: {{title}}

## Definition
[1-2 Sätze: Welches wiederkehrende Muster steckt dahinter?]

## Zugehörige Codes
- #code/

## Repräsentative Zitate
> "" — [Interview-ID]
> "" — [Interview-ID]

## Widersprechende Evidenz
[Was widerspricht oder relativiert dieses Theme? "Bisher keine" nur, wenn ehrlich geprüft.]

## Offene Fragen
[Was ist zu diesem Theme noch unklar / zu prüfen?]

## Verknüpfte Pain Points
- 

## Verknüpfte Insights
- 

## Referenz
Siehe [[Definitionen]] für Confidence-Kriterien, [[SOP-Analyseprozess]] für den Gesamtprozess.