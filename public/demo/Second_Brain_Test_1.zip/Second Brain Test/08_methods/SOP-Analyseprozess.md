# SOP: Analyseprozess für Interviews

## Rolle / Haltung
Ziel ist nicht, Interviews zusammenzufassen. Zusammenfassungen verdichten Information und verlieren Evidenz.
Ziel ist, **Evidenz zu synthetisieren** – jede Aussage muss auf ein konkretes Zitat einer konkreten Person zurückführbar sein.
Testfrage bei jedem Schritt: "Könnte ich auf den exakten Satz zeigen, der das stützt?" Wenn nein: das ist noch keine Synthese, sondern ein Eindruck.

## Grundprinzip: Integrieren statt neu erfinden
Falls bereits Themes/Insights existieren: neue Evidenz wird an Bestehendes angehängt (Codes zu bestehenden Themes,
Interview-Count erhöhen, widersprechende Evidenz ergänzen). Nur ein neues Theme anlegen, wenn die Evidenz wirklich
nirgendwo passt – und dann explizit begründen, warum kein bestehendes Theme passt.

## Die 9 Schritte

### 1. Lesen für Kontext (noch nicht coden)
Ganzes Transkript einmal lesen. Notieren: Wer ist die Person? Welche Situation/Workflow? Was will sie erreichen?
Welche Emotionen kamen auf? Noch NICHTS markieren – sonst werden Sätze aus dem Kontext gerissen und falsch codiert.

### 2. In Meaning Units zerlegen
Eine Aussage/ein Gedanke = eine Einheit. Macht die Person in einem Atemzug drei Punkte, sind das drei Einheiten.

### 3. Codes vergeben
Kurzes Label pro Meaning Unit, nah an der Wortwahl der Person (in-vivo).
Beispiel gut: "Misstraut Export-Button". Beispiel schlecht (zu früh abstrahiert): "Geringes Systemvertrauen".

### 4. Codes mit bestehenden Themes abgleichen
- Passt zu bestehendem Theme → anhängen, Interview-/Zitat-Count erhöhen, notieren ob es das Theme bestätigt oder relativiert.
- Passt nirgends → neues Theme, aber erst prüfen ob ein bestehendes Theme nur umbenannt/erweitert werden sollte.

### 5. Themes ausbauen
Jedes Theme braucht: Name, Definition, zugehörige Codes, Interview Count (unterschiedliche Interviews, nicht Zitate),
Quote Count, Confidence (siehe Definitionen.md), Segmente, Contradicting Evidence, Research Gaps.

### 6. Pain Points identifizieren
Ein Pain Point ist eine konkrete, spezifische Reibung – nicht das ganze Theme (das ist das übergeordnete Muster).
Jeder Pain Point gehört zu GENAU EINEM Theme. Spannt er über zwei Themes: entweder Pain Point splitten,
oder die zwei Themes sind eigentlich eins.
Felder: Pain Point, Theme, Beschreibung, Trigger, Impact, Workaround, Severity, Confidence, Evidence Count,
Interview-IDs, Zitate.

### 7. Needs identifizieren
Vier Kategorien:
- Funktional: was will die Person auf Aufgabenebene erreichen
- Emotional: wie will sie sich fühlen (oder nicht mehr fühlen)
- Sozial: wie will sie von anderen wahrgenommen werden
- Latent: nicht direkt ausgesprochen, aber aus der Evidenz ableitbar – explizit als Inferenz kennzeichnen

### 8. Insights generieren
Ein Insight verbindet mehrere Themes bzw. erklärt WARUM ein Muster von Pain Points existiert.
Braucht: mehrere stützende Themes, stützende Zitate, Confidence, Impact.
WICHTIG: Ist die Evidenz dünn, KEIN Insight schreiben – stattdessen in Research Gaps/offene Fragen packen.
Lieber wenige solide Insights als viele erfundene.

### 9. Recommendations generieren
Jede Recommendation verweist auf GENAU EIN Insight (kann verwandte Insights zusätzlich nennen, braucht aber einen
klaren Anker). Nie eine Recommendation ohne Insight-Bezug schreiben – sonst ist es nur eine Idee ohne Evidenz.

## Regeln (gelten durchgehend, nicht nur am Ende)
- Nie Sentiment-Analyse (positiv/negativ-Scoring) als Ersatz für echtes thematisches Denken verwenden
- Nie Word-Clouds oder Häufigkeits-Visualisierungen als Analyse-Ersatz nutzen
- Nie nur nach Häufigkeit gewichten. Wichtigkeit = Impact × Evidenzqualität × Wiederholung über Interviews × Severity.
  Ein Pain Point, den eine Person als blockierend beschreibt, kann wichtiger sein als einer, den fünf beiläufig erwähnen.
- Zitate immer im Original belassen – nicht glätten oder umformulieren
- Evidenz immer rückverfolgbar halten – von jedem Theme/Pain Point/Insight zurück zum Interview
- Annahmen sichtbar von Beobachtungen trennen – Inferenzen als solche kennzeichnen
- Unklares explizit als unklar markieren, nicht stillschweigend raten

## Verwandte Dateien
- [[Definitionen]] – wie Confidence, Severity und Evidenzqualität konkret bestimmt werden
- [[Qualitäts-Checkliste]] – vor Abschluss jeder Analyse durchgehen