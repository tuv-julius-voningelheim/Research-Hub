
## 1. Was ist das?

Ein Obsidian-Vault, der rohe Interview-Transkripte automatisiert (per KI-Agent) in strukturierte Research-Erkenntnisse verwandelt — Themes, Pain Points, Needs, Insights, Recommendations, Personas.

Ziel: Evidenz bleibt jederzeit bis zum Originalzitat zurückverfolgbar, bestehende Erkenntnisse werden angereichert statt dupliziert.
  
## 2. Ordnerstruktur


| `00_inbox-raw` | Unverarbeitete Transkripte — nur kurzzeitig, bis der Agent sie verarbeitet | **Mensch legt ab** (singulär - wichtig!) |

| `01_interviews` | Verarbeitete Interviews: Kontext, Meaning Units, Codes | **Agent** |

| `02_themes` | Wiederkehrende Muster über mehrere Codes/Interviews hinweg | **Agent** |

| `03_pain-points` | Konkrete, spezifische Reibungspunkte — je genau einem Theme zugeordnet | **Agent** |

| `04_needs` | Funktional / Emotional / Sozial / Latent — was Personen wirklich brauchen | **Agent** |

| `05_insights` | Synthese über mehrere Themes hinweg — das "Warum" hinter den Mustern | **Agent** |

| `06_recommendations` | Konkrete Handlungsempfehlungen, je an genau ein Insight verankert | **Agent** |

| `07_personas` | Nutzertypen — erst ab 3 konsistenten Interviews zulässig | **Agent** |

| `08_methods` | SOP, Definitionen, Qualitäts-Checkliste, Templates — die Spielregeln selbst | Mensch, fix |

| `09_archive` | Fertig verarbeitete Rohtranskripte | **Agent (Verschieben)** |

  

**Warum diese Reihenfolge:** Jede Stufe verdichtet die vorherige. Ein Insight braucht Themes, ein Theme braucht Codes — die Abhängigkeit ist logisch, nicht zeitlich.

## 3. Die drei Grundprinzipien

1. **Dedup vor Neuanlage.** Vor jeder neuen Notiz (egal welcher Typ) wird immer zuerst geprüft, ob eine bestehende Notiz thematisch bereits passt. Passt eine: dort ergänzen (Evidenz, Confidence, Zitate). Passt keine: neu anlegen, mit Begründung, warum nichts gepasst hat.

2. **Evidenz bleibt rückverfolgbar.** Jede Aussage muss auf ein konkretes Zitat einer konkreten  Person zurückführbar sein. Zitate werden nie geglättet oder umformuliert.

3. **Lieber ehrlich unvollständig als erfunden vollständig.** Ist die Evidenz dünn: kein Insight, keine Persona, keine Recommendation erzwingen — stattdessen offen als Lücke vermerken.

## 4. Confidence & Severity Kriterien

**Confidence** (wie sicher ist ein Muster echt?):

- **Hoch** — 3+ Interviews, konsistent, überwiegend direkte Aussagen, kaum Widersprüche

- **Mittel** — 2+ Interviews ODER 1 Interview mit starker direkter Evidenz

- **Niedrig** — nur 1 Interview, indirekt/abgeleitet — trotzdem festhalten, aber als vorläufig kennzeichnen

**Severity** (nur Pain Points — wie teuer ist es für den Nutzer?):

- **Kritisch** — blockiert die Aufgabe komplett / Datenverlust / Abbruch

- **Hoch** — erzwingt erheblichen Workaround, kostet wiederholt Zeit/Vertrauen

- **Mittel** — echte Reibung, aber Anpassung ohne große Kosten

- **Niedrig** — kleine Unannehmlichkeit, kaum Einfluss aufs Ergebnis


Wichtig: Severity ≠ Confidence. Ein einzelner kritischer Bericht (niedrige Confidence, hohe Severity) verdient oft gezielte Anschlussforschung, statt auf mehr Bestätigung zu warten.

**Personas — strenge Sonderregel:** Erst ab mindestens 3 unterschiedlichen Interviews mit konsistentem Muster. Vorher: Vermerk als "Proto-Segment", keine eigene Persona-Notiz.

## 5. Workflow — was beim Hochladen eines Transkripts passiert


1. Transkript wird in `00_inbox-raw` abgelegt

2. Agent liest SOP + Definitionen, vergibt Interview-ID (P01, P02, …)

3. Interview-Notiz: Kontext lesen → Meaning Units → Codes

4. Codes gegen bestehende Themes abgleichen (ergänzen oder neu anlegen)

5. Pain Points & Needs ableiten, gegen Bestehendes abgleichen

6. Insights nur bei ausreichend starker, verbindender Evidenz

7. Recommendations, je an ein Anker-Insight verankert

8. Proto-Segmente/Personas aktualisieren

9. Qualitäts-Checkliste durchgehen

10. Transkript nach `09_archive` verschieben


**Wichtig für Mehrfach-Uploads:** Immer nur ein Transkript gleichzeitig in `00_inbox-raw` — erst vollständig verarbeiten lassen, dann das nächste ablegen.

## 6. Tools im Zusammenspiel


- **Obsidian** — Leseoberfläche, Backlinks, Graph View, Canvas für freies visuelles Clustern

- **VS Code + KI-Agent (Copilot/Codex, Agent-Modus)** — führt die eigentliche Analyse aus,

  gesteuert über `.github/copilot-instructions.md`

- **`08_methods/`** — die einzige Quelle der Wahrheit für Methodik und Kriterien; wird von Menschen gepflegt, vom Agent nur gelesen


## 7. Qualitäts-Checkliste (Kurzfassung)


- Jedes Theme hat mind. ein Zitat als Beleg

- Jeder Pain Point gehört zu genau einem Theme

- Jede Recommendation verweist auf genau ein Insight

- Widersprechende Evidenz wird dokumentiert, nicht geglättet

- Confidence/Severity sind überall gesetzt, nie leer

- Keine Priorisierung nach reiner Häufigkeit — immer Impact × Evidenzqualität × Wiederholung × Severity  

*Stand: Pilot-Phase — Struktur bewusst schlank gehalten, wird bei Bedarf erweitert

(z. B. Synthese-Ebenen, Index-Datei, Research-Log), sobald sich das aus der Praxis ergibt.*