---
typ: interview
teilnehmer_id: "INT-001"
name: "Markus Bauer"
segment: TD-Bewerter
datum: "2026-06-30"
status: codiert
---

# Interview: Markus Bauer — INT-001

## Kontext (Schritt 1 — vor dem Coden)
- **Wer ist die Person?** Markus Bauer, Produktspezialist / TD Bewerter (Technical Documentation Assessor) bei TÜV SÜD seit 2020. Arbeitet sowohl für Loris- als auch Harris-Devices, also Medizinprodukte (MDR). Früher auch Application Management, heute primär Assessment-Phase.
- **Workflow/Aufgabe:** Erhält Projekte über das Scheduling Team (per E-Mail, Medici/TÜV-SüdWiki). Bewertet technische Dokumentation von Herstellern zur Produktzertifizierung. Verwaltet Projekte parallel in PSE 2.0, priorisiert nach Deadlines. Schreibt Assessment Reports, lädt diese in Medici hoch; danach folgt STC/LTR Review vor der Zertifizierung.
- **Was will er erreichen?** Effiziente, planbare Arbeit ohne unnötige Blockaden durch schlechte Daten, unklare Prozesse oder langsame Schnittstellen — besonders bei internationalen Projekten.
- **Emotionen:** Sachlich-nüchtern, erfahren. Frustriert über First-Come-First-Serve-Zuteilung und internationale Schnittstellenprobleme (3-Monats-Subcontract-Verzögerung). Vorsichtig optimistisch gegenüber MACE/neuen Tools. Pragmatisch: schlägt konkrete Verbesserungen vor (24h-Zeitfenster, Datenbankersatz für Appendix ABC).

---

## Transkript in Meaning Units

> „Da werden wir quasi angefragt per E-Mail eigentlich quasi... Da wird dann ein Item geöffnet für diesen Auftrag und dann bekommen dann verschiedene Bewerber, die die relevante Autorisierung dazu besitzen..."
Code: #code/projektzuteilung-email-medici

> „Das geht auch auf Zeit quasi. Also der als erstes First Come First Serve Prinzip quasi, das ist schon mal ein erster Punkt der schwierig ist ja. Weil meistens komme ich erst wenn ich am Projekt sitz sag ich mal am Ende des Tages dazu da reinzuschauen am nächsten Tag und dann merkt man eigentlich dass also wenn man nicht in den ersten ein, zwei, drei oder fünf Minuten klickt ist es eigentlich schon weg."
Code: #code/projektzuteilung-FCFS-problem

> „Ich denke das könnte auch schon mal ein Punkt sein der zu einer Ungleichverteilung von der Arbeitslast führt."
Code: #code/arbeitslast-ungleichverteilung

> „auf jeden Fall besser als First Come for Surfer schon mal 'n Zeitfenster, wir haben meinten meine erste Idee, sag ich mal 24 Stunden. und dann sieht man, wer klickt und dann muss man entscheiden... wer da wirklich am wenigsten Auslastung von den Leuten, die dann zugesagt haben"
Code: #code/zuteilung-zeitfenster-idee

> „Mit PSE 2.0 genau, da lass ich mal alle aktiven Projekte anzeigen, nach Startdatum oder nach Enddatum sortiert und dann priorisier ich entsprechend ja."
Code: #code/pse20-deadlines-priorisierung

> „wenn wirklich der Bewertungsslot losgeht, und ich sag mal, der Kunde hat auch tatsächlich eingereicht zu dem Zeitpunkt, wo er seine Bewertung einreichen sollte, dann ist es eigentlich immer komplett."
Code: #code/daten-vollständig-bei-bewertungsstart

> „wir haben noch so 'ne Art Completeness Checkliste, wo man vorab wirklich noch mal checken kann, sind alle wichtigen Dokumente da, dass man da keine Zeit verliert, wenn was komplett fehlt"
Code: #code/completeness-checkliste

> „Ich glaub, wir machen neues System, wenn wir schon 3 Projekte von einem Kunden hatten, dann gehen wir davon aus, quasi dass alles komplett ist, dann glaub ich, müssen wir den Completeness Check auch nicht mehr machen, nur noch bei Neukunden"
Code: #code/completeness-check-nur-neukunden

> „das Nächste ist dann für mich wirklich das Wichtigste, dieser Appendix ABC quasi, der mir genau sagt, welche Produkte sind betroffen, welche Codes haben die Produkte, dass ich die nötigen Autorisierungen für die Module rausfinden kann."
Code: #code/appendix-abc-hauptdatenquelle

> „es hat einen MDN-HILF04 Code für Weichgewebsimplantate... dann weiß ich gleich, die Autorisierung von dem dem Bewerter wird benötigt dafür, um das zu machen."
Code: #code/codes-autorisierung-verknüpfung

> „Das ist ein komplexes Dokument natürlich der Appendix A. B. C. auch verschiedenste Produkte aufgeführt werden... es kommen immer noch zu Rückfragen, auf jeden Fall. Manchmal ist auch nicht so ganz klar, ist der Code jetzt relevant für das Produkt oder nicht... da geht das bisschen hin und her und das kann viel Zeit kosten."
Code: #code/appendix-abc-komplexität-fehlerquellen

> „wenn es wirklich für uns klar ist, aus anderen Informationen, dass der Code einfach falsch ist und der andere wichtig wär, dass ich das quasi auch selber verbessern kann, mich selber als Autorun eintragen kann"
Code: #code/code-selbstkorrektur-möglich

> „Produktbeschreibung für mich auch und Internet Purpose... Das weiß ich schon mal, was ist das für ein Device, aus welchen Materialien besteht es, was, was soll das machen... Das sind so ein bisschen Freitextinformationen, die sehr wertvoll sind."
Code: #code/produktbeschreibung-wertvoller-kontext

> „Auch schon, auch schon ganz, ganz signifikante Application Management und Review Phase. weil das deutet mir schon mal drauf hin, welche Codes dann relevant sind."
Code: #code/produktbeschreibung-code-ableitung

> „Es gibt schon zum Beispiel, wenn da steht, es aus Metall, dann gibt es den Code für für Metal Processing... 'ne erste Abarbeitung ist gut und dann muss ich halt sich 'nen Experte nochmal anschauen, würd ich sagen, drüber gehen"
Code: #code/code-ableitung-automatisierung-potenzial

> „für mich wäre es ausreichend, wenn ich die Anzahl Devices Basic oder die I.D.I.s oder Produktfamilien hab, da rein noch nicht in Metall alle Varianten. Ist natürlich noch regulatorisch die Frage, weil wir genau wissen müssen, bei der Application schon, welche Basis das quasi vom was die Artikel angeht"
Code: #code/budi-anzahl-ausreichend-für-AM

> „tatsächlich dann welche Größen, wie welche Anzahl Varianten da schaue ich mir dann wirklich erst in der Bewertung an"
Code: #code/varianten-detail-erst-bei-bewertung

> „gibt so ein paar Redundanzen, also im Sheet 1 zum Beispiel... Die gleiche Information oder ähnlich habe ich aber dann noch mal in diesen Sheets dahinter, A. Punkt 2 oder A. Punkt 3 zum Beispiel für Sterilization... und die sind oft widersprüchlich und da kommt schon mal zu fragen, ja, war das jetzt 'n Fehler vom Kunden oder 'n Missverständnis"
Code: #code/appendix-supplier-redundanz-inkonsistenz

> „In der Application Phase sind Sites und Supplier eher weniger wichtig, würde ich sagen... Erst während der Bewertung dann schon"
Code: #code/sites-supplier-AM-irrelevant

> „wenn die Datenqualität gut ist, wie es im PSE 20 eingetragen ist, dann sehe ich da eigentlich alles"
Code: #code/pse20-gut-gepflegt-vollübersicht

> „die legen die Tasks nur an, quasi um damit man sie auch buchen können... nicht um irgendeine Ablaufplanung oder Übersicht zu ermöglichen, ne. Und wenn das so gehandhabt wird, dann habe ich eigentlich keinerlei Übersicht mehr."
Code: #code/pse20-internationale-nutzung-keine-übersicht

> „muss man aufpassen, dass nicht zwei Tools hat PSE 2.0 und ein weiteres Tool, dass dann beide versuchen das gleiche zu machen"
Code: #code/tool-duplizierung-risiko

> „ist aber noch absolut in Übergangsphase momentan... momentan wirklich bisher nur für Herstellerdaten, Adresse gut war und die ganzen Sachen mit Zertifikaten, Produktdaten, die kommen jetzt erst langsam"
Code: #code/eudamed-übergangsphase

> „ich hatte ein Projekt, da haben wir wiederholt immer wieder nachgefragt und wir haben kein Subcontract bekommen. Ohne den können wir eigentlich, wenn wir nicht keinen Auftrag haben, können nicht buchen können, können wir auch nicht arbeiten, eigentlich. Es gibt die Regulatoria vor, ich denk, da hat 3 Monate gebraucht, bis dann Subcontract da war, was eigentlich noch keine Ahnung an dem halben Tag gehen gehen sollte oder könnte."
Code: #code/subcontract-verzögerung-blockierend

> „wenn es am Anfang schon falsch eingespurt wurde, falsche Bewerterautorisierungen oder falsch falsche Schiene quasi vom Assessment am Ende des Projekts merkt man dann, dass da hab ich, kenn ich jetzt eher vom"
Code: #code/falscher-track-bei-projektstart

> „wenn der Appendix ABC in der aktuellen Version für alle zugänglich wäre oder aufrufbar wäre... ich frag auch immer den Customer Specialist oder Relationship Manager, weil der weiß meistens, wo ist was ist der aktuellste, die aktuellste Version von Appendix A. B. C. Das kostet ein bisschen... wenn der gerade im Urlaub ist oder was, kann natürlich auch ein bisschen Zeit kosten"
Code: #code/appendix-version-zugang-umständlich

> „ich denke, der größte Pain Point für Kunden ist, wenn wenn die Timeline nicht eingehalten werden, weil der Kunde, der muss zuverlässig wissen, wann wann ist jetzt eine Bewertung fertig... dieser letzte Schritt quasi vor der Zertifizierung, wenn es dann im Review ist durch STC... Da war zwar auch eine Timeline in unseren Servicemodellen, aber da da kommt es oft zu Rückfragen quasi, dann verschiebt sich oder verlängert sich der Slot."
Code: #code/timeline-unsicherheit-zertifizierungsphase

> „vergleicht man das mit der tatsächlichen Zeit, wie lange es dauert. A. to C. nennen wir diesen diesen Key K. K. I. also von der Application bis zur Certification... sieht man sicher die Diskrepanz, dass es in der Realität deutlich länger dauert."
Code: #code/planungsdauer-vs-realität-diskrepanz

> „ich muss immer wieder die Working Instructions der aktuellen Version auch daneben legen, um die korrekt durchzuführen... Es kostet schon immer wieder Zeit, also ich muss mich immer wieder ein bisschen einlesen, hat sich etwas getan, gibt es Neuerungen"
Code: #code/working-instructions-manuell-nachschlagen

> „wir haben so viele verschiedene Projekttypen... Change Notifications auch über T. D. über Renewals, initiale Zertifizierungen, darum noch spezielle Special Projects... das ändert sich auch von außen. Regulatorisch gibt es auch mal wieder Änderungen"
Code: #code/viele-projekttypen-prozessvarianten

> „wenn in einem Tool dann die immer angezeigt werden würde für dieses Projekt... welche Prozesse, welche Procedures quasi, welche Working Instructions, welche Reports brauche ich jetzt genau für dieses Projekt. Ich denke, das kann sehr, sehr hilfreich sein, ja."
Code: #code/prozessführung-im-tool-gewünscht

> „bei PSE 20 gibt es noch bisschen Geschwindigkeitsprobleme, gerade wenn ich von zu aus arbeite, wenn ich da 'n Projector öffne, nicht erst mal 'n paar Sekunden warten muss, bei jedem Klick bis man Dateien anzeigt."
Code: #code/pse20-performance-probleme

> „muss man sich immer die Projektnummer, irgendeine Referenz SAP Nummer oder oder PSE Projektnummer reinschreiben, dass ich 'ne Referenz irgendeinen Anhaltspunkt habe, welches Projekt geht es quasi."
Code: #code/kommunikation-fehlende-projektzuordnung

> „wenn es Richtung Indien geht, habe ich jetzt persönlich eher schlecht... Erfahrungen gemacht, warte mal so lang auf die Antwort und dann geht es wieder erst zum Manager. Der Manager muss dann wieder dem Project Lander sagen, er muss das machen. Also da geht es sehr oft hin und her und dann wartet man halt wirklich Wochen und Monate"
Code: #code/internationale-kommunikation-langsam-indien

> „'n Plattformgedanke, quasi 'ne Plattformlösung, wo dann wirklich von Anfang von Application bis zum Ende des Zertifikats und auch danach dann noch vielleicht Post Certification, vielleicht der Status überwacht wird"
Code: #code/plattformlösung-end-to-end-vision

> „für die Bewertung nutze ich oder probier ich ganz gerne auch das IDAS Tool aus, quasi wo A.I. gestützt dann 'ne Bewertung macht. Ist 'n erster Prototyp, sag ich mal, ab dem geht auf jeden Fall in die richtige Richtung"
Code: #code/idas-ki-bewertung-positiv

> „auf jeden Fall der Gedanke, auf jeden Fall der Richtige, genau, dass man den überführt von Excel in in 'ne Datenbankl ösung"
Code: #code/appendix-zu-datenbank-ansatz-richtig

> „wenn man es vielleicht noch vereinfachen kann für den Kunden, wie gesagt, dass der vielleicht im noch mehr in die Hand genommen wird, dass er die richtigen Codes einträgt, auch automatisch Sachen, die vielleicht so Doppelredundanzen, die dann Inkonsistenzen erzeugen, rausnimmt"
Code: #code/kundenguidance-codes-und-validierung

## Referenz
Siehe [[SOP-Analyseprozess]] Schritt 1–3.
