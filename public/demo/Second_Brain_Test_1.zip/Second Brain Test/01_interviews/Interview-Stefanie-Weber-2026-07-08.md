---
typ: interview
teilnehmer_id: "INT-003"
name: "Stefanie Weber"
segment: Customer Specialist + Auditor
datum: "2026-07-08"
status: codiert
---

# Interview: Stefanie Weber — INT-003

## Kontext (Schritt 1 — vor dem Coden)
- **Wer ist die Person?** Stefanie Weber, seit 4 Jahren bei TÜV SÜD. Dual-Rolle: ~30-40% Auditorin, ~60-70% Customer Specialist. Betreut einen großen Bestandskunden (betreuungsintensiv, hohe Projektlast) sowie einige kleinere Kunden. Bewertet selbst KEINE technischen Dokumentationen; koordiniert TD-Assessment und macht selbst Audit. Für Change Notifications erstellt sie auch „Significant Change"-Bewertungen (Decision of significant change).
- **Workflow/Aufgabe:** Empfängt Service Requests via UCI (bevorzugt) oder E-Mail; prüft Vollständigkeit der Application + Appendix ABC; erstellt Kostenkalkulation; übergibt an PC für PSE-Anlage und Angebotserstellung; koordiniert den gesamten Prozess bis Assessment/Audit. Pflegt parallel eine eigene Excel-Liste als Projekttracking.
- **Was will sie erreichen?** Einen klar strukturierten Arbeitsfluss, in dem sie sofort sieht, was als nächstes zu tun ist ("bei wem liegt der Ball"). Weniger manuelle Bereinigung von Appendix-ABC-Daten. Offizielle Kalkulationsvorlagen für alle Falltypen. Klare Gebührenregeln.
- **Emotionen:** Pragmatisch, selbstkritisch ("ich bin jetzt gerade auch schlecht, gebe ich zu, meine eigenen Unteraufträge zu pflegen"), lösungsorientiert, fürsprechend für Kunden. Frustriert über redundante Arbeit (PC-Timeline-E-Mails, Appendix-Cleanup). Enthusiastisch bei der Idee eines End-to-End-Tools.

---

## Transkript in Meaning Units

> „Tatsächlich ist es mir über UCI lieber, eigentlich aus dem Grund, weil... wenn Sie es erst zu mir schicken per E-Mail... muss ich das manuell erstmal weiterleiten an die PC... bei U.C.I. ist eigentlich so 'n bisschen klarer die Verantwortung, O.K., jetzt muss ist die P.C. am Zug."
Code: #code/uci-bevorzugt-klare-verantwortung

> „dazwischen noch ganz wichtig, dass er da diese Application einreicht. Er hat eine Idee... den Antrag rein und dann machen wir ein Projekt auf, weil erst dann haben wir diese Projektreferenznummer, die wir dann in allen weiteren Sachen irgendwie anziehen können."
Code: #code/projektnummer-als-prozessvoraussetzung

> „stellen die sich manchmal schlauer und mal dümmer an, da irgendwie die Häkchen richtig zu machen oder das auszufüllen... da gibt es schon öfter mal dass ich das wieder zurückschicke"
Code: #code/formblatt-fehler-kunden-häufig

> „zu 90 Prozent muss zu dieser Application gehört auch dieser Appendix ABC dazu... meistens nicht so, dass sie da überhaupt den Appendix ABC mitschicken, geschweige denn da schon die Änderung irgendwie drin haben"
Code: #code/appendix-abc-fehlt-oder-unvollständig-bei-einreichung

> „der Augenblick so ganz bewusst ist, wann ändere ich diesen Appendix ABC? Erst wenn der Change quasi von uns akzeptiert ist oder schon am Anfang, das sind so typische Sachen, die ich immer wieder erklären muss."
Code: #code/appendix-abc-zeitpunkt-unklar-change-kunden

> „gerade im Appendix ABC, da verliere ich glaube ich am meisten Zeit. Gerade wenn da viele Artikel drauf sind, dann also eigentlich ist jede Application, die mir mein Großkunde schickt, der irgendwie darauf abzielt, dauert extrem lange, weil in dieser Bearbeitung von der Application, im Endeffekt ich die Daten aufräume."
Code: #code/appendix-abc-cleanup-zeitfresser-cs

> „es fällt mir während des Assessments so wann Sachen auf wie, es gibt hier in einer Basic UDI verschiedene intended users. Dürfen sie eigentlich gar nicht haben. Solche Sachen könnte man ja auch elektronisch im Idealfall irgendwie schon vorab irgendwie klären, dass das gar nicht möglich ist, dass sie das dann eintragen können."
Code: #code/appendix-abc-validierung-elektronisch-lösbar

> „dann fällt mir während des Assessments so wann Sachen auf... dann geht es an den Kunden, dann müssen die sich erstmal fünf Wochen absprechen, dass sie irgendwie dann wieder eine neue Version schicken. Also das ist total aufwendig tatsächlich."
Code: #code/appendix-fehler-spät-entdeckt-fünf-wochen-rücklauf

> „da ist einerseits für uns, wenn ich auch schlecht bin, gebe ich zu, meine eigenen Unteraufträge zu pflegen... wünschte ich mir, wenn ich irgendwie... wenn sie in CC ist bei irgendeiner Mail und da deutlich hervorgeht, da verschiebt sich eine Timeline, dass sie das selbst erkennt und dann einfach eigenständig anpasst und ich nicht noch mal extra eine Mail an sie schreiben muss."
Code: #code/pc-timeline-nicht-eigenständig-angepasst

> „wenn ich die Rechte hätte, in der Zeit, wo ich ihr dann noch mal die E-Mail schreibe, dass ihr die Timeline anfasst oder ich dann meine Projekte durchflüge, wo die Timelines nicht passen, da könnt ich es einfach direkt selber updaten in dem Sinne."
Code: #code/cs-fehlende-pse-editierrechte

> „Bei mir ist es auch oft so, dass ich irgendwie Supplier Audit kalkuliere, da kann ich mir wieder anscheinend alles aus dem Daumen schütteln... Change Notifications, da gibt es nicht so eine richtig offizielle Vorlage... nichts, was in ROXPA ist und so ein bisschen inoffiziell läuft."
Code: #code/kalkulation-fehlende-offizielle-vorlage

> „anscheinend nie ganz klar, jetzt mit diesen Gebühren. Also brauche ich eine Multiplied Body Review Fee, brauche ich eine Certification Review Fee... das wissen beide einfach selber nicht und dann entscheiden sie einfach irgendwas."
Code: #code/fee-regelung-unklar-niemand-weiß

> „Ich war mir gerade bei Kleinkunden, da läuft ja noch nicht so viel auf einmal, das weiß ich noch so auskindlich, aber bei dem Großen, da kriege ich im Endeffekt selber eine Liste, die ist nicht schön, aber im Endeffekt einfach nur, wo ich auch wirklich so Kleinigkeiten einfach reinschreibe."
Code: #code/excel-tracking-eigenbau-weil-kein-tool

> „gerade weil es zu viele sind bei denen, gucke ich da schon irgendwie alle zwei Wochen mal, wenn ich denke, okay ich habe da jetzt schon länger nichts mehr gehört und was für ein Status ist, das heißt ach ja, jetzt erwarten wir jetzt auch die Rückmeldung vom Kunden, wann wollt ihr uns die nochmal geben?"
Code: #code/manuelles-nachverfolgen-alle-zwei-wochen

> „das wäre cool, dass man so das so sehen könnte, okay bei wem liegt gerade der Ball in dem Sinne und muss ich überhaupt irgendwas machen, muss ich aktiv werden."
Code: #code/ball-bei-wem-responsibility-visibility

> „dass dieses Nachverfolgen vielleicht auch gar nicht mehr nötig ist, weil der andere dann ja auch sieht, bei ihm liegt der Ball und dann vielleicht von alleine irgendwie eine Mail kriegt oder was auch immer, hier was ist denn damit, mach mal fertig oder so."
Code: #code/automatische-benachrichtigung-bei-handlungsbedarf

> „diese zwei Kanäle sind auch manchmal eher ein Hindernis, dass man das irgendwie nachverfolgen kann."
Code: #code/zwei-kanäle-uci-email-hindernis

> „das versuche ich jetzt eher dann alles per U.C.I. zu machen, wenn ich da irgendwas nachfrage oder so... pro Projekt halt die Kommunikation einfach da nachvollziehen kann, ich erst irgendwie 1000 Mails nach."
Code: #code/uci-projektkommunikation-traceability

> „also wäre halt richtig cool, wenn das irgendwie alles nicht in Excel wäre, sondern die Informationen in Daten irgendwie gespeichert wäre, da Cross-Checks automatisch möglich sind. bestimmte Sachen gar nicht einzugeben sind durch den Kunden, weil das nicht geht regulatorischer aus regulatorischer Sicht."
Code: #code/appendix-abc-datenbank-mit-validierung-gewünscht

> „vielleicht ein paar Fragen am Anfang kommen, hier was möchtest du machen, ich möchte das und das machen und dann werden entsprechend irgendwie ja Informationen abgefragt... dann brauchen Sie vielleicht gar kein Formblatt mehr ausfüllen."
Code: #code/geführter-antragsprozess-kunden-wizard

> „gerade bei vielen Daten, die sich gerade ein großer Kunde wahrscheinlich auch wünschen, dass da irgendwie eine Schnittstelle zu irgendeinem SAP oder so möglich ist, dass die mindestens beim initialen Upload oder dass man das irgendwie hinkriegen kann."
Code: #code/sap-schnittstelle-appendix-upload-kundenwunsch

> „Appendix A. B. C. Also das krieg ich schon regelmäßig als Rückmeldung, dass das schwierig ist."
Code: #code/appendix-abc-schwierig-kundenfeedback-direkt

> „ich würde mir wünschen, dass das irgendwie beibehalten wird, also das jetzt nicht nur einmal Input ist, sondern das was auch immer ihr jetzt damit macht, dann irgendwie noch mal Feedback von uns da eingeholt wird."
Code: #code/iterativer-entwicklungsprozess-gewünscht

> „muss ich jetzt 'ne Kalkulation, also hängt das jetzt gerade an mir, dass ich, dass ich 'n Arbeitspaket bei mir habe oder hängt das dann an an meiner P. C., dass sie jetzt das Angebot erstellen muss, ist das rausgegangen, Hat der Kunde es angenommen und so weiter."
Code: #code/offene-arbeitspakete-sichtbarkeit-gewünscht

## Referenz
Siehe [[SOP-Analyseprozess]] Schritt 1–3.
