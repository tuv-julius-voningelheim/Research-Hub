---
typ: interview
teilnehmer_id: "INT-002"
name: "Sebastian Reuter"
segment: Dual-autorisierter Bewerter/Auditor
datum: "unbekannt (Datei: P02.md)"
status: codiert
---

# Interview: Sebastian Reuter — INT-002

## Kontext (Schritt 1 — vor dem Coden)
- **Wer ist die Person?** Sebastian Reuter, dual-autorisierter Bewerter/Auditor bei TÜV SÜD. Hat sowohl Autorisierungen für technische Dokumentationsbewertung (MDA/MDN-Codes) als auch für Audits (MDT-Codes). Ingenieurshintergrund, 4 Jahre mit Metallbearbeitungsthemen. Kennt den Prozess aus beiden Perspektiven (Audit-Pfad + TD-Pfad).
- **Typ dieser Sitzung:** Prototyp-Evaluation (Follow-up-Sitzung) — das Team zeigt Sebastian Screens aus MACE Application und erholt Reaktionen. Gemisch aus Usability-Feedback und Discovery. Erste Sitzung hatte bereits stattgefunden ("Das letzte Mal sind wir so ein bisschen stehen geblieben").
- **Workflow/Aufgabe:** Bewertet aus der Perspektive eines Senior Specialists, der sowohl Audit-Planung als auch TD-Assessment-Planung überblickt. Erwähnt Customer Specialists als diejenigen, die Codes im Application Management festlegen.
- **Was will er erreichen?** Ein Tool, das seinen tatsächlichen Arbeitsfluss unterstützt (macro → micro: Technologiecodes zuerst, dann Produktfamilien); klare Trennung von Audit- und TD-Pfad; Transparenz über Änderungen und Projektstatus; weniger manuelle Kommunikation.
- **Emotionen:** Kritisch-analytisch, sachlich. Frustriert über fehlende Änderungstransparenz ("Ein Riesenproblem in unserem System"). Pragmatisch und offen gegenüber neuen Lösungen (AI-Code-Prescription als "sehr sexy", DHL-Tracking als Wunschbild). Humorvoll, aber direkt in der Kritik.

---

## Transkript in Meaning Units

> „im Grundsatz ist diese Oberfläche sehr ambiguous, also komplett undefiniert. Ich sehe weder einen Identifier für ein Projekt, das wir initialisiert haben mit der Anfrage, den ich dann zu der Applications hinzufügen könnte und ich sehe auch keine Application ID."
Code: #code/screen-application-id-fehlt

> „Es doppelt sich ja zwischen Characteristics of Product Family und den Codes. Die Charakteristiken sind die Codes."
Code: #code/characteristics-codes-dopplung

> „diese Großteil von dem, was ich hier gerade sehe, ist eine doppelte Dekoration. Im Endeffekt brauchte ich bisher hier absolut gar nichts, was mir die Codes nicht unten sagen würden."
Code: #code/characteristics-nur-dekoration

> „diese Codes festlegen, welcher Bewerter dafür qualifiziert ist, weil er darauf trainiert wird... Das heißt, hier kann es zu einer Deviation kommen... das für die Bewertungsplanung relevant ist."
Code: #code/codes-steuern-bewerterqualifikation

> „Da fehlen jetzt zum Beispiel die MDT Codes. Die MDT Codes sind relevant für die Auditplanung."
Code: #code/mdt-codes-fehlen-im-screen

> „Natürlich nicht. Kann er nicht. Kann er nicht oder verbockt er manchmal einfach? Beides. Es ist erstens hyperkomplex."
Code: #code/kunde-versteht-codes-nicht

> „Das macht der Customer Specialist... Und das auch immer nach Best Guess. im Endeffekt wie so eine Steuererklärung nach bestem Wissen und Gewissen."
Code: #code/customer-specialist-codes-best-guess

> „was wir typischerweise für diese Produkte haben, wäre hier ein riesen Add-on. Also ist die Prescription of Codes. Sehe ich hier als cool, wenn ihr da irgendwie so ein AI-Tool einbaut, Prescription of Codes oder irgendwie Equivalence Products oder so, wäre das natürlich sehr sexy."
Code: #code/ki-code-vorschlag-wertvoll

> „In der Ansicht, die ich sehe, ist es ein bisschen umgedreht, wie der Arbeitsprozess läuft und zwar erstmal makroskopisch rauf zu gucken, bis man ins Mikroskopische geht. Was für Technologien habe ich, was für einen Produkttypen habe ich und dann kommt irgendwann, welches Produkt ist es eigentlich?"
Code: #code/informationsarchitektur-umgekehrt

> „Grundsätzlich würde ich glaube ich die UI so ändern, dass ich dann oben Audit sehe und unten Product Details."
Code: #code/ui-audit-vs-product-trennung

> „die Varianten und die Family Devices sind fürs Audit unerheblich, außer man geht ins Audit und geht durch die Produktliste"
Code: #code/varianten-für-audit-irrelevant

> „diese M.D.A. M.D.N. Codes müssen alle Produkte und alle Spezifikationen abdecken. Noch schöner wäre es zu sehen, aus welchem Produkt die Änderung kommt. Das wäre sehr sexy."
Code: #code/codes-alle-produkte-ganzheitliche-ansicht

> „Site-Informationen sind genau das, was ich da oben mit dem Audit meinte, mit den Codes, die sehr relevant sind für die Audit-Planung."
Code: #code/site-informationen-audit-relevant

> „anwendbare Regulatorik für Schemes. Also MDR, MD Sub ISO... dann natürlich sowas wie Taiwan, die TCPB... und dann brauche ich die Mitarbeiterzahl und die Anwendbarkeit von Tätigkeiten."
Code: #code/site-daten-anforderungen

> „Diese Sichtweise, über die wir so standardmäßig reden, ist für Legalhersteller eigentlich eine riesen Blackbox. Also die verstehen gar nicht, was wollen die mit MDT und was passiert mit MDS und wann ist was. Deswegen, die machen dann das nach Best Guess und dann kommt es daran, dass wir sagen, okay, wo brauchen wir jetzt wirklich was."
Code: #code/appendix-abc-blackbox-für-kunden

> „Der normale Weg ist 'Hey, das ist mein Produkt' und dann sagen wir 'Füll mal bitte den Appendix ABC aus, die versuchen das nach dem Best Guest zu machen, ohne zu wissen, warum wir was anfragen.'"
Code: #code/appendix-abc-prozess-best-guess

> „Konsultationen, sowas wie ein Plantable Devices oder alles mit Medicinal Substances. So externe Behörden Sachen, die wir halt nicht beeinflussen können."
Code: #code/externe-konsultationen-timeline-kritisch

> „Ein Requeststatus in dem Sinne, der gemessen wird, gibt es bei uns nicht, außer mit dem Abschluss des Application Reviews. Denn wenn der Application Review abgeschlossen ist, habt ihr den formalen Status einer Request erfüllt, weil wir dann erst die Quotation ausstellen können."
Code: #code/application-review-abschluss-request-abgeschlossen

> „Ein Riesenproblem in unserem System ist die fehlende Transparenz von Änderungen. Wann wird welche Änderung wie gemacht, wer hat sie gemacht, wie wird sie gehighlightet, der Kunde sieht nicht, wenn wir was anpassen, dementsprechend hat man 'ne Verdummung von einem System oder eher gesagt, keine Verbesserung von einem dummen System."
Code: #code/änderungstransparenz-fehlt-systemisch

> „Es ist unsere Verantwortung, unsere Akkreditierung, wir legen fest, wie die Codes sind, Rücksprache mit dem Kunden."
Code: #code/tuv-verantwortung-finale-codes

> „müsste man dann eine nicht Service Request, aber eine Specification Request über sowas stellen können... hey, die following Concerns, die following Request habe ich, lieber Kunde, gib mir entweder 'ne Response oder buch dir 'n Meeting"
Code: #code/specification-request-funktion-gewünscht

> „Möchte ich, dass der Kunde von dieser Änderung mitbekommt oder nicht? Also ein Tick-off wäre schon smart."
Code: #code/kundenbenachrichtigung-optional-toggle

> „Diese Anwendbarkeit von Tasks, also diese Scope Definition, die kommt, wie gesagt, immer nach dem Application Review."
Code: #code/scope-definition-nach-application-review

> „Die Inputs dafür sind glaube ich gelistet, um den Application Review abzuschließen. Also die MDA, MDS, EMDN, MDT, EAC und MD Codes, die brauche ich alle."
Code: #code/codes-pflichtfelder-application-review

> „ein Abgleich wäre nicht verkehrt. Datenabgleich. Ob das jetzt die Single Source of Truth ist, würde ich noch mal in den Raum stellen... Als Datenabgleichsquelle ist das schon smart"
Code: #code/eudamed-als-validierungsquelle

> „Derzeit ist der Appendix A. B. C. die vollendete Wahrheit, die maßgeblich sein muss... Und auch das Dokument, das am häufigsten verändert wird, logischerweise. Weil es am unrichtigsten ist."
Code: #code/appendix-abc-häufigste-fehlerquelle-ssot

> „Wenn UCI abgeschifft wird, ja. Wenn es on top kommt, würde ich sagen nein."
Code: #code/kommunikation-kein-zusätzlicher-kanal

> „Tracking von Projektstatus ist mit Sicherheit eine wichtige Sache. wenn man das hier einbauen könnte wie bei einem DHL Paket, in welchem Status wir uns befinden, wo das Paket sich gerade befindet."
Code: #code/projektstatus-tracking-dhl-wunsch

> „Für mich noch viel besser als für den Kunden ehrlich gesagt. Und das freizugeben für den Kunden on demand."
Code: #code/status-tracking-primär-intern-dann-extern

> „Ein Eskalationsknopf wäre natürlich super toll... einen Prio-Knopf oder einen Tribute... für Auseinandersetzungen oder auch von Entscheidungsfindung mit einer Messbarkeit, von Anfrage bis zur Entscheidung, das wäre phänomenal."
Code: #code/eskalationsknopf-mit-entscheidungsmessung

> „auch ein Kommunikationsfinder wäre sehr cool, um zu tracken, welche Informationen geteilt wurden."
Code: #code/kommunikations-audit-trail

> „Thema Datenrestriktion denke ich, dass es Sinn ergeben kann, dass Leute alles sehen, aber definitiv nicht alle Rechte haben... man nichts verstecken sollte, weil Leute sich abbilden könnten dadurch. Aber nicht jeder sollte überall Bearbeitungsrechte haben, sondern eher Sichtrechte."
Code: #code/sichtrechte-ohne-editierrechte

> „gibt es oft die Anfragen, wer der Senior Product Specialist ist, der letztendlich Produktentscheidungen treffen kann. Auch hier kann man einen Anfrageknopf für Entscheidungen starten."
Code: #code/senior-specialist-kontakt-anfrage

> „Da unten ist er, okay, da unten ist der EMDN-Code. Und dann, genau, der MDT-Code fehlt. Die Mitarbeiterzahl sehe ich nicht."
Code: #code/screen-fehlende-pflichtfelder

## Referenz
Siehe [[SOP-Analyseprozess]] Schritt 1–3.
